<div <?php qode_framework_class_attribute( $holder_classes ); ?> <?php qode_framework_inline_attr( $slider_attr, 'data-options' ); ?>>
	<div <?php qode_framework_class_attribute( $static_section_classes ); ?>>
		<div class="qodef-e-static-left">
			<?php halstein_core_template_part( 'blog/shortcodes/blog-slider-with-text', 'templates/post-info/static-tagline', '', $params ); ?>
			<?php halstein_core_template_part( 'blog/shortcodes/blog-slider-with-text', 'templates/post-info/static-title', '', $params ); ?>
		</div>
		<div class="qodef-e-static-right">
			<?php halstein_core_template_part( 'content', 'templates/swiper-nav', '', $params ); ?>
		</div>
	</div>
	<div class="swiper-wrapper">
		<?php
		// Include items
		halstein_core_template_part( 'blog/shortcodes/blog-list', 'templates/loop', '', $params );
		?>
	</div>
	<?php halstein_core_template_part( 'content', 'templates/swiper-pag', '', $params ); ?>
</div>
