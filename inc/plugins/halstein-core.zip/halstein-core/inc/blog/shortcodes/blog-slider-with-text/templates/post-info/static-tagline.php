<?php if ( ! empty( $static_tagline ) ) : ?>
	<h6 class="qodef-e-static-tagline">
		<?php echo esc_html( $static_tagline ); ?>
	</h6>
<?php endif; ?>
