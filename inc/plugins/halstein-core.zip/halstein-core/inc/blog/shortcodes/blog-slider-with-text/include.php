<?php

include_once HALSTEIN_CORE_INC_PATH . '/blog/shortcodes/blog-slider-with-text/class-halsteincore-blog-slider-with-text-shortcode.php';
