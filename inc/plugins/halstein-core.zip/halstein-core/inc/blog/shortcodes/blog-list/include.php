<?php

include_once HALSTEIN_CORE_INC_PATH . '/blog/shortcodes/blog-list/class-halsteincore-blog-list-shortcode.php';

foreach ( glob( HALSTEIN_CORE_INC_PATH . '/blog/shortcodes/blog-list/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
