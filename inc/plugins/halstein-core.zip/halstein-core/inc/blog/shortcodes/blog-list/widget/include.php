<?php

include_once HALSTEIN_CORE_INC_PATH . '/blog/shortcodes/blog-list/widget/class-halsteincore-blog-list-widget.php';
include_once HALSTEIN_CORE_INC_PATH . '/blog/shortcodes/blog-list/widget/class-halsteincore-simple-blog-list-widget.php';
