<?php

if ( ! function_exists( 'halstein_core_add_blog_list_variation_metro' ) ) {
	/**
	 * Function that add variation layout for this module
	 *
	 * @param array $variations
	 *
	 * @return array
	 */
	function halstein_core_add_blog_list_variation_metro( $variations ) {
		$variations['metro'] = esc_html__( 'Metro', 'halstein-core' );

		return $variations;
	}

	add_filter( 'halstein_core_filter_blog_list_layouts', 'halstein_core_add_blog_list_variation_metro' );
}
