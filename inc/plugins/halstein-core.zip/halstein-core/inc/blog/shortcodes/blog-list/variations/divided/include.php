<?php

include_once HALSTEIN_CORE_INC_PATH . '/blog/shortcodes/blog-list/variations/divided/divided.php';
