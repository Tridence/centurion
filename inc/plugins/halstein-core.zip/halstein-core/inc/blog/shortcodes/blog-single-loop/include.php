<?php

include_once HALSTEIN_CORE_INC_PATH . '/blog/shortcodes/blog-single-loop/class-halsteincore-blog-single-loop.php';

foreach ( glob( HALSTEIN_CORE_INC_PATH . '/blog/shortcodes/blog-single-loop/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
