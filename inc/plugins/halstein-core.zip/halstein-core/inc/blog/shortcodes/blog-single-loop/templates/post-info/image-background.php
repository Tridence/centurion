<?php
$blog_list_image = get_post_meta( get_the_ID(), 'qodef_blog_list_image', true );
$has_image       = ! empty( $blog_list_image ) || has_post_thumbnail();
?>

<?php if ( $has_image ) : ?>
	<?php
	$image_url = halstein_core_get_list_shortcode_item_image_url( 'full', $blog_list_image );
	$style     = ! empty( $image_url ) ? 'background-image: url( ' . esc_url( $image_url ) . ')' : '';
	?>
	<div class="qodef-e-media-image qodef--background" <?php qode_framework_inline_style( $style ); ?>></div>
<?php endif; ?>
