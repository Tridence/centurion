<div class="qodef-e-post-comment">
	<?php
	$button_params = array(
		'link'          => get_the_permalink() . '#qodef-page-comments-form',
		'text'          => esc_html__( 'Post Comment', 'halstein-core' ),
		'button_layout' => 'filled-two',
	);

	echo HalsteinCore_Button_Shortcode::call_shortcode( $button_params );
	?>
</div>
