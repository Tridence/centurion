<?php

if ( $query_result->have_posts() ) :
	while ( $query_result->have_posts() ) :
		$query_result->the_post();

		$params['image_dimension'] = $this_shortcode->get_list_item_image_dimension( $params );
		$params['item_classes']    = $this_shortcode->get_item_classes( $params, get_the_ID() );
		$params['current_page']    = intval( $query_result->query['paged'] );
		$params['max_pages']       = intval( $query_result->max_num_pages );

		halstein_core_list_sc_template_part( 'blog/shortcodes/blog-single-loop', 'layouts/' . $layout, get_post_format(), $params );
	endwhile; // End of the loop.
else :
	// Include global posts not found
	halstein_core_theme_template_part( 'content', 'templates/parts/posts-not-found' );
endif;

wp_reset_postdata();
