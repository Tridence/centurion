<?php echo get_the_term_list( get_the_ID(), 'category', '', '<span class="qodef-info-separator-single"></span>' ); ?>
<div class="qodef-info-separator-end"></div>
