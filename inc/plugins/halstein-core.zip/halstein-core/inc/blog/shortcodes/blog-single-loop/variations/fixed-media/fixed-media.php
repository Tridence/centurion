<?php

if ( ! function_exists ( 'halstein_core_add_blog_single_loop_variation_fixed_media' ) ) {
    function halstein_core_add_blog_single_loop_variation_fixed_media ( $variations ) {
        $variations[ 'fixed-media' ] = esc_html__ ( 'Fixed Media', 'halstein-core' );

        return $variations;
    }

    add_filter ( 'halstein_core_filter_blog_single_loop_layouts', 'halstein_core_add_blog_single_loop_variation_fixed_media' );
}

if ( ! function_exists ( 'halstein_core_add_blog_single_loop_variation_fixed_media_force_atts' ) ) {
    /**
     * Function that force atts for variation
     *
     * @return array $atts
     */
    function halstein_core_add_blog_single_loop_variation_fixed_media_force_atts () {
        $atts = array ();

        $atts[ 'behavior' ]          = 'columns';
        $atts[ 'images_proportion' ] = 'full';
        $atts[ 'space' ]             = 'no';
        $atts[ 'posts_per_page' ]    = 1;
        $atts[ 'pagination_type' ]   = 'simple';
        $atts[ 'title_tag' ]         = 'h1';
        $atts[ 'enable_excerpt' ]    = 'yes';
        $atts[ 'enable_author' ]     = 'yes';

        return $atts;
    }
}
