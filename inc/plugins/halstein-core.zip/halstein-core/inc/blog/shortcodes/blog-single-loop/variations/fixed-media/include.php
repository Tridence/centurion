<?php

include_once HALSTEIN_CORE_INC_PATH . '/blog/shortcodes/blog-single-loop/variations/fixed-media/fixed-media.php';
