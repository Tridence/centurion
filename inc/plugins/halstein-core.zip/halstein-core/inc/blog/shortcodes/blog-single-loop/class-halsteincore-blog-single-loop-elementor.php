<?php

class HalsteinCore_Blog_Single_Loop_Shortcode_Elementor extends HalsteinCore_Elementor_Widget_Base {

	public function __construct( array $data = [], $args = null ) {
		$this->set_shortcode_slug( 'halstein_core_blog_single_loop' );

		parent::__construct( $data, $args );
	}
}

halstein_core_get_elementor_widgets_manager()->register( new HalsteinCore_Blog_Single_Loop_Shortcode_Elementor() );
