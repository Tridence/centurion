<?php

if ( ! function_exists( 'halstein_core_add_blog_single_loop_shortcode' ) ) {
	/**
	 * Function that is adding shortcode into shortcodes list for registration
	 *
	 * @param array $shortcodes - Array of registered shortcodes
	 *
	 * @return array
	 */
	function halstein_core_add_blog_single_loop_shortcode( $shortcodes ) {
		$shortcodes[] = 'HalsteinCore_Blog_Single_Loop_Shortcode';

		return $shortcodes;
	}

	add_filter( 'halstein_core_filter_register_shortcodes', 'halstein_core_add_blog_single_loop_shortcode' );
}

if ( class_exists( 'HalsteinCore_List_Shortcode' ) ) {
	class HalsteinCore_Blog_Single_Loop_Shortcode extends HalsteinCore_List_Shortcode {

		public function __construct() {
			$this->set_post_type( 'post' );
			$this->set_post_type_taxonomy( 'category' );
			$this->set_post_type_additional_taxonomies( array( 'post_tag' ) );
			$this->set_layouts( apply_filters( 'halstein_core_filter_blog_single_loop_layouts', array() ) );
			$this->set_extra_options( apply_filters( 'halstein_core_filter_blog_single_loop_extra_options', array() ) );

			parent::__construct();
		}

		public function map_shortcode() {
			$this->set_shortcode_path( HALSTEIN_CORE_INC_URL_PATH . '/blog/shortcodes/blog-single-loop' );
			$this->set_base( 'halstein_core_blog_single_loop' );
			$this->set_name( esc_html__( 'Blog Single Loop', 'halstein-core' ) );
			$this->set_description( esc_html__( 'Shortcode that displays single post with ajax loop', 'halstein-core' ) );
			$this->set_category( esc_html__( 'Halstein Core', 'halstein-core' ) );
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'custom_class',
					'title'      => esc_html__( 'Custom Class', 'halstein-core' ),
				)
			);
			$this->map_query_options( array( 'exclude_posts_per_page' => true ) );
			$this->map_layout_options(
				array(
					'layouts'        => $this->get_layouts(),
					'exclude_option' => array( 'title_tag', 'text_transform' ),
				)
			);
			$this->map_extra_options();
		}

		public static function call_shortcode( $params ) {
			$html = qode_framework_call_shortcode( 'halstein_core_blog_single_loop', $params );
			$html = str_replace( "\n", '', $html );

			return $html;
		}

		public function render( $options, $content = null ) {
			parent::render( $options );

			$atts = $this->get_atts();

			// Force atts
			if ( function_exists( 'halstein_core_add_blog_single_loop_variation_' . str_replace( '-', '_', $atts['layout'] ) . '_force_atts' ) ) {
				$force_atts = call_user_func( 'halstein_core_add_blog_single_loop_variation_' . str_replace( '-', '_', $atts['layout'] ) . '_force_atts' );
				$atts       = array_merge( $atts, $force_atts );
			}

			$atts['post_type']       = $this->get_post_type();
			$atts['taxonomy_filter'] = $this->get_post_type_taxonomy();

			// Additional query args
			$atts['additional_query_args'] = $this->get_additional_query_args( $atts );

			$atts['holder_classes'] = $this->get_holder_classes( $atts );
			$atts['query_result']   = new \WP_Query( halstein_core_get_query_params( $atts ) );
			$atts['data_attr']      = halstein_core_get_pagination_data( HALSTEIN_CORE_REL_PATH, 'blog/shortcodes', 'blog-single-loop', 'post', $atts );

			$atts['this_shortcode'] = $this;

			return halstein_core_get_template_part( 'blog/shortcodes/blog-single-loop', 'templates/content', $atts['behavior'], $atts );
		}

		private function get_holder_classes( $atts ) {
			$holder_classes = $this->init_holder_classes();

			$holder_classes[] = 'qodef-blog';
			$holder_classes[] = 'qodef-blog-single-loop';
			$holder_classes[] = ! empty( $atts['layout'] ) ? 'qodef-item-layout--' . $atts['layout'] : '';

			$list_classes   = $this->get_list_classes( $atts );
			$holder_classes = array_merge( $holder_classes, $list_classes );

			return implode( ' ', $holder_classes );
		}

		public function get_item_classes( $atts, $id ) {
			$item_classes = $this->init_item_classes();

			$item_classes[] = 'qodef-blog-item';

			$list_item_classes = $this->get_list_item_classes( $atts, $id );

			$item_classes = array_merge( $item_classes, $list_item_classes );

			return implode( ' ', $item_classes );
		}

		public function get_item_styles( $atts ) {
			return array();
		}

		public function get_title_styles( $atts ) {
			$styles = array();

			if ( ! empty( $atts['text_transform'] ) ) {
				$styles[] = 'text-transform: ' . $atts['text_transform'];
			}

			return $styles;
		}
	}
}
