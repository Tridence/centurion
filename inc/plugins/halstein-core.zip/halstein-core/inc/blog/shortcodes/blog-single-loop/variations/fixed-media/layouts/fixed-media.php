<article <?php post_class( $item_classes ); ?>>
	<div class="qodef-e-inner">
		<div class="qodef-e-fixed">
			<?php
			// Include post featured image
			halstein_core_template_part( 'blog/shortcodes/blog-single-loop', 'templates/post-info/image', 'background', $params );
			?>
			<div class="qodef-e-content">
				<?php
				// Include  post title
				halstein_core_template_part( 'blog/shortcodes/blog-list', 'templates/post-info/title', '', $params );
				?>
			</div>
		</div>
		<div class="qodef-e-scroll">
			<div class="qodef-e-top-holder">
				<div class="qodef-e-left qodef-e-info">
					<?php
					// Include post author
					halstein_core_template_part( 'blog/shortcodes/blog-single-loop', 'templates/post-info/author', '', $params );
					?>
				</div>
				<div class="qodef-e-right qodef-e-info">
					<?php
					// Include post category info
					halstein_core_template_part( 'blog/shortcodes/blog-single-loop', 'templates/post-info/categories' );
					?>
				</div>
			</div>
			<div class="qodef-e-text">
				<?php
				// Include post content
				halstein_core_render_post_content( get_the_ID() );

				// Hook to include additional content after blog single content
				do_action( 'halstein_action_after_blog_single_content' );
				?>
			</div>
			<div class="qodef-e-bottom-holder">
				<div class="qodef-e-left qodef-e-info">
					<?php
					// Include post tags info
					halstein_core_template_part( 'blog/shortcodes/blog-single-loop', 'templates/post-info/tags' );
					?>
				</div>
				<div class="qodef-e-right qodef-e-info">
					<?php
					// Include post social share info
					halstein_core_template_part( 'blog/shortcodes/blog-single-loop', 'templates/post-info/social-share' );
					?>
				</div>
			</div>
			<?php
			// Include author post info
			halstein_core_template_part( '/blog/templates/single/author-info', 'templates/author-info' );

			// Include post comments
			halstein_core_template_part( '/blog/shortcodes/blog-single-loop', 'templates/post-info/comment' );
			?>
		</div>
	</div>
</article>
