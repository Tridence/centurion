<a itemprop="author" href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>" class="qodef-e-info-author">
	<?php if ( false !== get_avatar( get_the_author_meta( 'ID' ) ) ) : ?>
		<?php echo wp_kses_post( get_avatar( get_the_author_meta( 'ID' ), 50 ) ); ?>
	<?php endif; ?>
	<?php the_author_meta( 'display_name' ); ?>
</a>
<div class="qodef-info-separator-end"></div>
