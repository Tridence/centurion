<div class="qodef-e-info-item qodef--social-share">
	<?php
	$params = array(
		'layout' => 'text',
	);

	echo HalsteinCore_Social_Share_Shortcode::call_shortcode( $params );
	?>
</div>
