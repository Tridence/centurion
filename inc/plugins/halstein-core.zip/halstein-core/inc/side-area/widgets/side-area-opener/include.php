<?php

include_once HALSTEIN_CORE_INC_PATH . '/side-area/widgets/side-area-opener/class-halsteincore-side-area-opener-widget.php';
