<?php

if ( ! function_exists( 'halstein_core_add_side_area_opener_widget' ) ) {
	/**
	 * Function that add widget into widgets list for registration
	 *
	 * @param array $widgets
	 *
	 * @return array
	 */
	function halstein_core_add_side_area_opener_widget( $widgets ) {
		$widgets[] = 'HalsteinCore_Side_Area_Opener_Widget';

		return $widgets;
	}

	add_filter( 'halstein_core_filter_register_widgets', 'halstein_core_add_side_area_opener_widget' );
}

if ( class_exists( 'QodeFrameworkWidget' ) ) {
	class HalsteinCore_Side_Area_Opener_Widget extends QodeFrameworkWidget {

		public function map_widget() {
			$this->set_base( 'halstein_core_side_area_opener' );
			$this->set_name( esc_html__( 'Halstein Side Area Opener', 'halstein-core' ) );
			$this->set_description( esc_html__( 'Display a "hamburger" icon that opens the side area', 'halstein-core' ) );
			$this->set_widget_option(
				array(
					'field_type'  => 'text',
					'name'        => 'sidea_area_opener_margin',
					'title'       => esc_html__( 'Opener Margin', 'halstein-core' ),
					'description' => esc_html__( 'Insert margin in format: top right bottom left', 'halstein-core' ),
				)
			);
			$this->set_widget_option(
				array(
					'field_type' => 'color',
					'name'       => 'side_area_opener_color',
					'title'      => esc_html__( 'Opener Color', 'halstein-core' ),
				)
			);
			$this->set_widget_option(
				array(
					'field_type' => 'color',
					'name'       => 'side_area_opener_hover_color',
					'title'      => esc_html__( 'Opener Hover Color', 'halstein-core' ),
				)
			);
			$this->set_widget_option(
				array(
					'field_type' => 'text',
					'name'       => 'side_area_opener_label',
					'title'      => esc_html__( 'Opener Label', 'halstein-core' ),
				)
			);
		}

		public function render( $atts ) {
			$side_area_text = ! empty( $atts['side_area_opener_label'] ) ? esc_html( $atts['side_area_opener_label'] ) : '';

			$styles = array();

			if ( ! empty( $atts['side_area_opener_color'] ) ) {
				$styles[] = 'color: ' . $atts['side_area_opener_color'] . ';';
			}

			if ( ! empty( $atts['sidea_area_opener_margin'] ) ) {
				$styles[] = 'margin: ' . $atts['sidea_area_opener_margin'];
			}

			halstein_core_get_opener_icon_html(
				array(
					'option_name'  => 'side_area',
					'custom_class' => 'qodef-side-area-opener',
					'inline_style' => $styles,
					'inline_attr'  => qode_framework_get_inline_attr( $atts['side_area_opener_hover_color'], 'data-hover-color' ),
					'custom_html'  => ! empty( $side_area_text ) ? '<span class="qodef-m-label qodef-side-area-opener-text">' . $side_area_text . '</span>' : '',
				)
			);
		}
	}
}
