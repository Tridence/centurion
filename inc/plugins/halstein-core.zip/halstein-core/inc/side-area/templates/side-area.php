<?php if ( is_active_sidebar( 'qodef-side-area-top' ) || is_active_sidebar( 'qodef-side-area-bottom' ) ) { ?>
	<div id="qodef-side-area" <?php qode_framework_class_attribute( $classes ); ?>>
		<?php
		halstein_core_get_opener_icon_html(
			array(
				'option_name'  => 'side_area',
				'custom_id'    => 'qodef-side-area-close',
				'custom_class' => 'qodef--opened',
			),
			false,
			true
		);
		?>
		<div id="qodef-side-area-inner">
		<?php if ( is_active_sidebar( 'qodef-side-area-top' ) ) { ?>
			<div id="qodef-side-area-top">
				<?php dynamic_sidebar( 'qodef-side-area-top' ); ?>
			</div>
		<?php } ?>
		<?php if ( is_active_sidebar( 'qodef-side-area-bottom' ) ) { ?>
			<div id="qodef-side-area-bottom">
				<?php dynamic_sidebar( 'qodef-side-area-bottom' ); ?>
			</div>
		<?php } ?>
		</div>
	</div>
<?php } ?>
