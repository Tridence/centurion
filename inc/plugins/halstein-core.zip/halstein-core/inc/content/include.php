<?php

include_once HALSTEIN_CORE_INC_PATH . '/content/helper.php';
