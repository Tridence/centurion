<div class="qodef-m-spinner-heading">
	<h3 class="qodef-m-spinner-text"><?php esc_html_e( 'Loading', 'halstein-core' ); ?></h3>
	<h5 class="qodef-m-spinner-number">
		<span class="qodef-m-spinner-number-label">0</span>
		<span class="qodef-m-spinner-number-mark">%</span>
	</h5>
</div>
<div class="qodef-m-spinner-line">
	<span class="qodef-m-spinner-line-front"></span>
</div>
