<?php
$spinner_title    = halstein_core_get_post_value_through_levels( 'qodef_page_spinner_title' );
$spinner_subtitle = halstein_core_get_post_value_through_levels( 'qodef_page_spinner_subtitle' );
?>

<div class="qodef-m-halstein">
	<div class="qodef-m-title">
		<?php esc_html_e( $spinner_title, 'halstein-core' ); ?>
	</div>
	<div class="qodef-m-subtitle">
		<?php esc_html_e( $spinner_subtitle, 'halstein-core' ); ?>
	</div>
</div>
