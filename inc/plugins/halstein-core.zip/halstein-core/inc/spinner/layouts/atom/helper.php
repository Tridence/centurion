<?php

if ( ! function_exists( 'halstein_core_add_atom_spinner_layout_option' ) ) {
	/**
	 * Function that set new value into page spinner layout options map
	 *
	 * @param array $layouts - module layouts
	 *
	 * @return array
	 */
	function halstein_core_add_atom_spinner_layout_option( $layouts ) {
		$layouts['atom'] = esc_html__( 'Atom', 'halstein-core' );

		return $layouts;
	}

	add_filter( 'halstein_core_filter_page_spinner_layout_options', 'halstein_core_add_atom_spinner_layout_option' );
}
