<?php

include_once HALSTEIN_CORE_INC_PATH . '/spinner/layouts/two-rotating-circles/helper.php';
