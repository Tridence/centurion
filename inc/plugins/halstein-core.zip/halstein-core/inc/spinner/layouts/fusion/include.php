<?php

include_once HALSTEIN_CORE_INC_PATH . '/spinner/layouts/fusion/helper.php';
