<?php

if ( ! function_exists( 'halstein_core_add_page_spinner_options' ) ) {
	/**
	 * Function that add general options for this module
	 */
	function halstein_core_add_page_spinner_options( $page ) {

		if ( $page ) {
			$page->add_field_element(
				array(
					'field_type'    => 'yesno',
					'name'          => 'qodef_enable_page_spinner',
					'title'         => esc_html__( 'Enable Page Spinner', 'halstein-core' ),
					'description'   => esc_html__( 'Enable Page Spinner Effect', 'halstein-core' ),
					'default_value' => 'no',
				)
			);

			$spinner_section = $page->add_section_element(
				array(
					'name'       => 'qodef_page_spinner_section',
					'title'      => esc_html__( 'Page Spinner Section', 'halstein-core' ),
					'dependency' => array(
						'show' => array(
							'qodef_enable_page_spinner' => array(
								'values'        => 'yes',
								'default_value' => 'no',
							),
						),
					),
				)
			);

			$spinner_section->add_field_element(
				array(
					'field_type'    => 'select',
					'name'          => 'qodef_page_spinner_type',
					'title'         => esc_html__( 'Select Page Spinner Type', 'halstein-core' ),
					'description'   => esc_html__( 'Choose a page spinner animation style', 'halstein-core' ),
					'options'       => apply_filters( 'halstein_core_filter_page_spinner_layout_options', array() ),
					'default_value' => apply_filters( 'halstein_core_filter_page_spinner_default_layout_option', '' ),
				)
			);

			$spinner_section->add_field_element(
				array(
					'field_type'    => 'text',
					'name'          => 'qodef_page_spinner_title',
					'title'         => esc_html__( 'Spinner Title', 'halstein-core' ),
					'description'   => esc_html__( 'Enter the spinner title', 'halstein-core' ),
					'default_value' => 'halstein',
					'dependency'    => array(
						'show' => array(
							'qodef_page_spinner_type' => array(
								'values'        => 'halstein',
								'default_value' => ''
							)
						)
					)
				)
			);

			$spinner_section->add_field_element(
				array(
					'field_type'    => 'text',
					'name'          => 'qodef_page_spinner_subtitle',
					'title'         => esc_html__( 'Spinner Subtitle', 'halstein-core' ),
					'description'   => esc_html__( 'Enter the spinner subtitle', 'halstein-core' ),
					'default_value' => 'solutions',
					'dependency'    => array(
						'show' => array(
							'qodef_page_spinner_type' => array(
								'values'        => 'halstein',
								'default_value' => ''
							)
						)
					)
				)
			);

			$spinner_section->add_field_element(
				array(
					'field_type'  => 'image',
					'name'        => 'qodef_page_spinner_background_image',
					'title'       => esc_html__( 'Spinner Background Image', 'halstein-core' ),
					'description' => esc_html__( 'Choose the spinner background image', 'halstein-core' ),
				)
			);

			$spinner_section->add_field_element(
				array(
					'field_type'  => 'color',
					'name'        => 'qodef_page_spinner_background_color',
					'title'       => esc_html__( 'Spinner Background Color', 'halstein-core' ),
					'description' => esc_html__( 'Choose the spinner background color', 'halstein-core' ),
				)
			);

			$spinner_section->add_field_element(
				array(
					'field_type'  => 'color',
					'name'        => 'qodef_page_spinner_color',
					'title'       => esc_html__( 'Spinner Color', 'halstein-core' ),
					'description' => esc_html__( 'Choose the spinner color', 'halstein-core' ),
				)
			);

			$spinner_section->add_field_element(
				array(
					'field_type'    => 'text',
					'name'          => 'qodef_page_spinner_text',
					'title'         => esc_html__( 'Spinner Text', 'halstein-core' ),
					'description'   => esc_html__( 'Enter the spinner text', 'halstein-core' ),
					'default_value' => 'halstein',
					'dependency'    => array(
						'show' => array(
							'qodef_page_spinner_type' => array(
								'values'        => 'textual',
								'default_value' => ''
							)
						)
					)
				)
			);

			$spinner_section->add_field_element(
				array(
					'field_type'    => 'yesno',
					'name'          => 'qodef_page_spinner_fade_out_animation',
					'title'         => esc_html__( 'Enable Fade Out Animation', 'halstein-core' ),
					'description'   => esc_html__( 'Enabling this option will turn on fade out animation when leaving page', 'halstein-core' ),
					'default_value' => 'no',
				)
			);
		}
	}

	add_action( 'halstein_core_action_after_general_options_map', 'halstein_core_add_page_spinner_options' );
}
