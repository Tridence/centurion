<?php

if ( ! function_exists( 'halstein_core_add_general_options' ) ) {
	/**
	 * Function that add general options for this module
	 */
	function halstein_core_add_general_options( $page ) {

		if ( $page ) {
			$page->add_field_element(
				array(
					'field_type'  => 'color',
					'name'        => 'qodef_main_color',
					'title'       => esc_html__( 'Main Color', 'halstein-core' ),
					'description' => esc_html__( 'Choose the most dominant theme color', 'halstein-core' ),
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'color',
					'name'        => 'qodef_page_background_color',
					'title'       => esc_html__( 'Page Background Color', 'halstein-core' ),
					'description' => esc_html__( 'Set background color', 'halstein-core' ),
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'image',
					'name'        => 'qodef_page_background_image',
					'title'       => esc_html__( 'Page Background Image', 'halstein-core' ),
					'description' => esc_html__( 'Set background image', 'halstein-core' ),
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_page_background_repeat',
					'title'       => esc_html__( 'Page Background Image Repeat', 'halstein-core' ),
					'description' => esc_html__( 'Set background image repeat', 'halstein-core' ),
					'options'     => array(
						''          => esc_html__( 'Default', 'halstein-core' ),
						'no-repeat' => esc_html__( 'No Repeat', 'halstein-core' ),
						'repeat'    => esc_html__( 'Repeat', 'halstein-core' ),
						'repeat-x'  => esc_html__( 'Repeat-x', 'halstein-core' ),
						'repeat-y'  => esc_html__( 'Repeat-y', 'halstein-core' ),
					),
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_page_background_size',
					'title'       => esc_html__( 'Page Background Image Size', 'halstein-core' ),
					'description' => esc_html__( 'Set background image size', 'halstein-core' ),
					'options'     => array(
						''        => esc_html__( 'Default', 'halstein-core' ),
						'contain' => esc_html__( 'Contain', 'halstein-core' ),
						'cover'   => esc_html__( 'Cover', 'halstein-core' ),
					),
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_page_background_attachment',
					'title'       => esc_html__( 'Page Background Image Attachment', 'halstein-core' ),
					'description' => esc_html__( 'Set background image attachment', 'halstein-core' ),
					'options'     => array(
						''       => esc_html__( 'Default', 'halstein-core' ),
						'fixed'  => esc_html__( 'Fixed', 'halstein-core' ),
						'scroll' => esc_html__( 'Scroll', 'halstein-core' ),
					),
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_page_content_padding',
					'title'       => esc_html__( 'Page Content Padding', 'halstein-core' ),
					'description' => esc_html__( 'Set padding that will be applied for page content in format: top right bottom left (e.g. 10px 5px 10px 5px)', 'halstein-core' ),
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_page_content_padding_mobile',
					'title'       => esc_html__( 'Page Content Padding Mobile', 'halstein-core' ),
					'description' => esc_html__( 'Set padding that will be applied for page content on mobile screens (1024px and below) in format: top right bottom left (e.g. 10px 5px 10px 5px)', 'halstein-core' ),
				)
			);

			$page->add_field_element(
				array(
					'field_type'    => 'yesno',
					'name'          => 'qodef_boxed',
					'title'         => esc_html__( 'Boxed Layout', 'halstein-core' ),
					'description'   => esc_html__( 'Set boxed layout', 'halstein-core' ),
					'default_value' => 'no',
				)
			);

			$boxed_section = $page->add_section_element(
				array(
					'name'       => 'qodef_boxed_section',
					'title'      => esc_html__( 'Boxed Layout Section', 'halstein-core' ),
					'dependency' => array(
						'hide' => array(
							'qodef_boxed' => array(
								'values'        => 'no',
								'default_value' => '',
							),
						),
					),
				)
			);

			$boxed_section->add_field_element(
				array(
					'field_type'  => 'color',
					'name'        => 'qodef_boxed_background_color',
					'title'       => esc_html__( 'Boxed Background Color', 'halstein-core' ),
					'description' => esc_html__( 'Set boxed background color', 'halstein-core' ),
				)
			);

			$boxed_section->add_field_element(
				array(
					'field_type'  => 'image',
					'name'        => 'qodef_boxed_background_pattern',
					'title'       => esc_html__( 'Boxed Background Pattern', 'halstein-core' ),
					'description' => esc_html__( 'Set boxed background pattern', 'halstein-core' ),
				)
			);

			$boxed_section->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_boxed_background_pattern_behavior',
					'title'       => esc_html__( 'Boxed Background Pattern Behavior', 'halstein-core' ),
					'description' => esc_html__( 'Set boxed background pattern behavior', 'halstein-core' ),
					'options'     => array(
						'fixed'  => esc_html__( 'Fixed', 'halstein-core' ),
						'scroll' => esc_html__( 'Scroll', 'halstein-core' ),
					),
				)
			);

			$page->add_field_element(
				array(
					'field_type'    => 'yesno',
					'name'          => 'qodef_passepartout',
					'title'         => esc_html__( 'Passepartout', 'halstein-core' ),
					'description'   => esc_html__( 'Enabling this option will display a passepartout around website content', 'halstein-core' ),
					'default_value' => 'no',
				)
			);

			$passepartout_section = $page->add_section_element(
				array(
					'name'       => 'qodef_passepartout_section',
					'title'      => esc_html__( 'Passepartout Section', 'halstein-core' ),
					'dependency' => array(
						'hide' => array(
							'qodef_passepartout' => array(
								'values'        => 'no',
								'default_value' => '',
							),
						),
					),
				)
			);

			$passepartout_section->add_field_element(
				array(
					'field_type'  => 'color',
					'name'        => 'qodef_passepartout_color',
					'title'       => esc_html__( 'Passepartout Color', 'halstein-core' ),
					'description' => esc_html__( 'Choose background color for passepartout', 'halstein-core' ),
				)
			);

			$passepartout_section->add_field_element(
				array(
					'field_type'  => 'image',
					'name'        => 'qodef_passepartout_image',
					'title'       => esc_html__( 'Passepartout Background Image', 'halstein-core' ),
					'description' => esc_html__( 'Set background image for passepartout', 'halstein-core' ),
				)
			);

			$passepartout_section->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_passepartout_size',
					'title'       => esc_html__( 'Passepartout Size', 'halstein-core' ),
					'description' => esc_html__( 'Enter size amount for passepartout', 'halstein-core' ),
					'args'        => array(
						'suffix' => esc_html__( 'px or %', 'halstein-core' ),
					),
				)
			);

			$passepartout_section->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_passepartout_size_responsive',
					'title'       => esc_html__( 'Passepartout Responsive Size', 'halstein-core' ),
					'description' => esc_html__( 'Enter size amount for passepartout for smaller screens (1024px and below)', 'halstein-core' ),
					'args'        => array(
						'suffix' => esc_html__( 'px or %', 'halstein-core' ),
					),
				)
			);

			$page->add_field_element(
				array(
					'field_type'    => 'select',
					'name'          => 'qodef_content_width',
					'title'         => esc_html__( 'Initial Width of Content', 'halstein-core' ),
					'description'   => esc_html__( 'Choose the initial width of content which is in grid (applies to pages set to "Default Template" and rows set to "In Grid")', 'halstein-core' ),
					'options'       => halstein_core_get_select_type_options_pool( 'content_width', false ),
					'default_value' => '1300',
				)
			);

			// Hook to include additional options after module options
			do_action( 'halstein_core_action_after_general_options_map', $page );

			$page->add_field_element(
				array(
					'field_type'  => 'textarea',
					'name'        => 'qodef_custom_js',
					'title'       => esc_html__( 'Custom JS', 'halstein-core' ),
					'description' => esc_html__( 'Enter your custom JavaScript here', 'halstein-core' ),
				)
			);
		}
	}

	add_action( 'halstein_core_action_default_options_init', 'halstein_core_add_general_options', halstein_core_get_admin_options_map_position( 'general' ) );
}
