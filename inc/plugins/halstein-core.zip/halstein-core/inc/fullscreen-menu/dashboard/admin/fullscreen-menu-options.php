<?php

if ( ! function_exists( 'halstein_core_fullscreen_menu_options' ) ) {
	/**
	 * Function that add global options for current module
	 */
	function halstein_core_fullscreen_menu_options() {
		$qode_framework = qode_framework_get_framework_root();

		$page = $qode_framework->add_options_page(
			array(
				'scope'       => HALSTEIN_CORE_OPTIONS_NAME,
				'type'        => 'admin',
				'slug'        => 'fullscreen-menu',
				'icon'        => 'fa fa-cog',
				'title'       => esc_html__( 'Fullscreen Menu', 'halstein-core' ),
				'description' => esc_html__( 'Global Fullscreen Menu Options', 'halstein-core' ),
			)
		);

		if ( $page ) {
			$page->add_field_element(
				array(
					'field_type'    => 'yesno',
					'name'          => 'qodef_fullscreen_menu_in_grid',
					'title'         => esc_html__( 'Fullscreen Menu in Grid', 'halstein-core' ),
					'default_value' => 'yes',
				)
			);

			$page->add_field_element(
				array(
					'field_type'    => 'yesno',
					'name'          => 'qodef_fullscreen_menu_hide_logo',
					'title'         => esc_html__( 'Fullscreen Menu Hide Logo', 'halstein-core' ),
					'description'   => esc_html__( 'Manage visibility of the logo area when menu is opened.', 'halstein-core' ),
					'default_value' => 'yes',
				)
			);

			$page->add_field_element(
				array(
					'field_type'    => 'yesno',
					'name'          => 'qodef_fullscreen_menu_hide_widget_area',
					'title'         => esc_html__( 'Fullscreen Menu Hide Widget Area', 'halstein-core' ),
					'description'   => esc_html__( 'Manage visibility of the widget area when menu is opened.', 'halstein-core' ),
					'default_value' => 'yes',
				)
			);

			$page->add_field_element(
				array(
					'field_type' => 'color',
					'name'       => 'qodef_fullscreen_menu_background_color',
					'title'      => esc_html__( 'Background Color', 'halstein-core' ),
				)
			);

			$page->add_field_element(
				array(
					'field_type' => 'image',
					'name'       => 'qodef_fullscreen_menu_background_image',
					'title'      => esc_html__( 'Background Image', 'halstein-core' ),
				)
			);

			$page->add_field_element(
				array(
					'field_type'    => 'select',
					'name'          => 'qodef_fullscreen_menu_icon_source',
					'title'         => esc_html__( 'Icon Source', 'halstein-core' ),
					'options'       => halstein_core_get_select_type_options_pool( 'icon_source', false ),
					'default_value' => 'predefined',
				)
			);

			$page->add_field_element(
				array(
					'field_type'    => 'select',
					'name'          => 'qodef_fullscreen_menu_icon_pack',
					'title'         => esc_html__( 'Icon Pack', 'halstein-core' ),
					'options'       => qode_framework_icons()->get_icon_packs( array( 'linea-icons', 'dripicons', 'simple-line-icons' ) ),
					'default_value' => 'elegant-icons',
					'dependency'    => array(
						'show' => array(
							'qodef_fullscreen_menu_icon_source' => array(
								'values'        => 'icon_pack',
								'default_value' => 'predefined',
							),
						),
					),
				)
			);

			$section_svg_path = $page->add_section_element(
				array(
					'title'      => esc_html__( 'SVG Path', 'halstein-core' ),
					'name'       => 'qodef_fullscreen_menu_svg_path_section',
					'dependency' => array(
						'show' => array(
							'qodef_fullscreen_menu_icon_source' => array(
								'values'        => 'svg_path',
								'default_value' => 'predefined',
							),
						),
					),
				)
			);

			$section_svg_path->add_field_element(
				array(
					'field_type'  => 'textarea',
					'name'        => 'qodef_fullscreen_menu_icon_svg_path',
					'title'       => esc_html__( 'Fullscreen Menu Open Icon SVG Path', 'halstein-core' ),
					'description' => esc_html__( 'Enter your full screen menu open icon SVG path here. Please remove version and id attributes from your SVG path because of HTML validation', 'halstein-core' ),
				)
			);

			$section_svg_path->add_field_element(
				array(
					'field_type'  => 'textarea',
					'name'        => 'qodef_fullscreen_menu_close_icon_svg_path',
					'title'       => esc_html__( 'Fullscreen Menu Close Icon SVG Path', 'halstein-core' ),
					'description' => esc_html__( 'Enter your full screen menu close icon SVG path here. Please remove version and id attributes from your SVG path because of HTML validation', 'halstein-core' ),
				)
			);

			$section_predefined = $page->add_section_element(
				array(
					'title'      => esc_html__( 'Predefined', 'halstein-core' ),
					'name'       => 'qodef_fullscreen_menu_predefined_section',
					'dependency' => array(
						'show' => array(
							'qodef_fullscreen_menu_icon_source' => array(
								'values'        => 'predefined',
								'default_value' => 'predefined',
							),
						),
					),
				)
			);

			$section_predefined->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_fullscreen_menu_icon_predefined_label',
					'title'       => esc_html__( 'Fullscreen Menu Opener Icon Label', 'halstein-core' ),
					'description' => esc_html__( 'Enter your full screen menu opener icon label here.', 'halstein-core' ),
				)
			);

			$section_opener_padding = $page->add_section_element(
				array(
					'title' => esc_html__( 'Opener Padding', 'halstein-core' ),
					'name'  => 'qodef_fullscreen_menu_opener_padding_section',
				)
			);

			$section_opener_padding->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_fullscreen_menu_opener_padding',
					'title'       => esc_html__( 'Fullscreen Menu Opener Padding', 'halstein-core' ),
					'description' => esc_html__( 'Enter opener padding value (top right bottom left)', 'halstein-core' ),
				)
			);

			// Hook to include additional options after module options
			do_action( 'halstein_core_action_after_fullscreen_menu_options_map', $page );
		}
	}

	add_action( 'halstein_core_action_default_options_init', 'halstein_core_fullscreen_menu_options', halstein_core_get_admin_options_map_position( 'fullscreen-menu' ) );
}
