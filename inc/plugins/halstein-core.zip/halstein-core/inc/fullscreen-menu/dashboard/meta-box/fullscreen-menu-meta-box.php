<?php

if ( ! function_exists( 'halstein_core_add_page_fullscreen_menu_meta_box' ) ) {
	/**
	 * Function that add general meta box options for this module
	 *
	 * @param object $page
	 */
	function halstein_core_add_page_fullscreen_menu_meta_box( $page, $section ) {

		if ( $page ) {

			$section->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_fullscreen_menu_opener_padding',
					'title'       => esc_html__( 'Fullscreen Menu Opener Padding', 'halstein-core' ),
					'description' => esc_html__( 'Enter opener padding value (top right bottom left)', 'halstein-core' ),
				)
			);
		}
	}

	add_action( 'halstein_core_action_after_page_minimal_header_meta_map', 'halstein_core_add_page_fullscreen_menu_meta_box', 10, 2 );
}
