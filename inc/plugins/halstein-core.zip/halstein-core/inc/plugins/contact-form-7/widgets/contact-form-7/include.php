<?php

include_once HALSTEIN_CORE_PLUGINS_PATH . '/contact-form-7/widgets/contact-form-7/class-halsteincore-contact-form-7-widget.php';
