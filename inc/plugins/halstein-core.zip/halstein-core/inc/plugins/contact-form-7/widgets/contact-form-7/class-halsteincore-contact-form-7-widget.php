<?php

if ( ! function_exists( 'halstein_core_add_contact_form_7_widget' ) ) {
	/**
	 * Function that add widget into widgets list for registration
	 *
	 * @param array $widgets
	 *
	 * @return array
	 */
	function halstein_core_add_contact_form_7_widget( $widgets ) {
		$widgets[] = 'HalsteinCore_Contact_Form_7_Widget';

		return $widgets;
	}

	add_filter( 'halstein_core_filter_register_widgets', 'halstein_core_add_contact_form_7_widget' );
}

if ( class_exists( 'QodeFrameworkWidget' ) ) {
	class HalsteinCore_Contact_Form_7_Widget extends QodeFrameworkWidget {

		public function map_widget() {
			$this->set_base( 'halstein_core_contact_form_7' );
			$this->set_name( esc_html__( 'Halstein Contact Form 7', 'halstein-core' ) );
			$this->set_description( esc_html__( 'Add contact form 7 to widget areas', 'halstein-core' ) );
			$this->set_widget_option(
				array(
					'field_type' => 'text',
					'name'       => 'widget_title',
					'title'      => esc_html__( 'Widget Title', 'halstein-core' ),
				)
			);
			$this->set_widget_option(
				array(
					'field_type' => 'select',
					'name'       => 'contact_form_id',
					'title'      => esc_html__( 'Select Contact Form 7', 'halstein-core' ),
					'options'    => qode_framework_get_cpt_items( 'wpcf7_contact_form', array( 'numberposts' => '-1' ) ),
				)
			);
			$this->set_widget_option(
				array(
					'field_type' => 'select',
					'name'       => 'skin',
					'title'      => esc_html__( 'Skin', 'halstein-core' ),
					'options'    => array(
						''      => esc_html__( 'Default', 'halstein-core' ),
						'light' => esc_html__( 'Light', 'halstein-core' ),
					),
				)
			);
			$this->set_widget_option(
				array(
					'field_type' => 'select',
					'name'       => 'button_layout',
					'title'      => esc_html__( 'Button Layout', 'halstein-core' ),
					'options'    => array(
						'filled-one' => esc_html__( 'Filled One', 'halstein-core' ),
						'filled-two' => esc_html__( 'Filled Two', 'halstein-core' ),
						'outlined'   => esc_html__( 'Outlined', 'halstein-core' ),
						'textual'    => esc_html__( 'Textual', 'halstein-core' ),
					),
				)
			);
			$this->set_widget_option(
				array(
					'field_type' => 'text',
					'name'       => 'width',
					'title'      => esc_html__( 'Width', 'halsteind-core' ),
				)
			);
		}

		public function render( $atts ) {
			$holder_classes[] = 'qodef-contact-form-7';
			$holder_classes[] = ! empty( $atts['skin'] ) ? 'qodef-skin--' . $atts['skin'] : '';
			$holder_classes[] = ! empty( $atts['button_layout'] ) ? 'qodef-button-layout--' . $atts['button_layout'] : '';

			?>
			<div <?php qode_framework_class_attribute( $holder_classes ); ?> <?php qode_framework_inline_style( $this->get_holder_styles( $atts ) ); ?>>
				<?php if ( ! empty( $atts['contact_form_id'] ) ) : ?>
					<?php echo do_shortcode( '[contact-form-7 id="' . esc_attr( $atts['contact_form_id'] ) . '"]' ); // XSS OK ?>
				<?php endif; ?>
			</div>
			<?php
		}

		public function get_holder_styles( $atts ) {
			$styles = array();

			$width = $atts['width'];
			if ( ! empty( $width ) ) {
				if ( qode_framework_string_ends_with_space_units( $width, true ) ) {
					$styles[] = 'width:' . $width;
				} else {
					$styles[] = 'width:' . intval( $width ) . 'px';
				}
			}

			return $styles;
		}
	}
}
