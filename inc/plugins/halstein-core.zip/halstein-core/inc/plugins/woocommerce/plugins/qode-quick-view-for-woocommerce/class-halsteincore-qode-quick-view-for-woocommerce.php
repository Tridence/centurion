<?php

if ( ! defined( 'ABSPATH' ) ) {
	// Exit if accessed directly.
	exit;
}

if ( ! class_exists( 'HalsteinCore_Qode_Quick_View_For_WooCommerce' ) ) {
	class HalsteinCore_Qode_Quick_View_For_WooCommerce {
		private static $instance;

		public function __construct() {
			add_action( 'init', array( $this, 'init' ), 20 );
		}

		/**
		 * @return HalsteinCore_Qode_Quick_View_For_WooCommerce
		 */
		public static function get_instance() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function init() {
			if ( qode_framework_is_installed( 'qode-quick-view-for-woocommerce' ) ) {
				// Unset default templates
				$this->unset_templates();

				// Add templates
				$this->add_templates();

				// Change position
				$this->change_templates_position();
			}
		}

		public function unset_templates() {
			// Override product title
			add_filter( 'qode_quick_view_for_woocommerce_filter_is_product_title_enabled', '__return_false' );
			add_action( 'qode_quick_view_for_woocommerce_action_product_summary', 'halstein_core_qode_quick_view_single_title', 5 );

			// Remove sale flash
			add_filter( 'qode_quick_view_for_woocommerce_filter_is_product_sale_flash_enabled', '__return_false' );

			// Remove star rating
			add_filter( 'qode_quick_view_for_woocommerce_filter_is_product_rating_enabled', '__return_false' );

			// Remove meta fields
			add_filter( 'qode_quick_view_for_woocommerce_filter_is_product_meta_enabled', '__return_false' );
		}

		function add_templates() {
			// Add rating
			add_action( 'qode_quick_view_for_woocommerce_action_product_summary', 'woocommerce_template_single_rating', 9 );
		}

		public function change_templates_position() {
			// Set button default value
			add_filter( 'qode_quick_view_for_woocommerce_filter_button_loop_position_default_value', array( $this, 'set_quick_view_button_loop_default_value' ) );

			// Set button position
			add_filter( 'qode_quick_view_for_woocommerce_filter_quick_view_button_loop_position', array( $this, 'set_quick_view_button_loop_position' ) );
		}

		public function set_quick_view_button_loop_position( $button_loop_position_map ) {
			$button_loop_position_map['shortcode'] = array(
				'action'   => 'halstein_woo_after_add_to_cart_template',
				'priority' => 10,
			);

			return $button_loop_position_map;
		}

		public function set_quick_view_button_loop_default_value() {
			return 'shortcode';
		}
	}

	HalsteinCore_Qode_Quick_View_For_WooCommerce::get_instance();
}
