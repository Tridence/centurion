<?php

if ( ! function_exists( 'halstein_core_qode_quick_view_single_title' ) ) {
	/**
	 * Function that override product single item title template
	 */
	function halstein_core_qode_quick_view_single_title() {
		// $option    = halstein_get_post_value_through_levels( 'qodef_woo_yith_quick_view_title_tag' );
		$title_tag = ! empty( $option ) ? esc_attr( $option ) : 'h2';

		echo '<' . esc_attr( $title_tag ) . ' class="qodef-woo-product-title product_title entry-title">' . wp_kses_post( get_the_title() ) . '</' . esc_attr( $title_tag ) . '>';
	}
}

if ( ! function_exists( 'halstein_core_add_qode_quick_view_link_to_single' ) ) {
	/**
	 * Insert the opening anchor tag for products in the loop.
	 */
	function halstein_core_add_qode_quick_view_link_to_single() {
		if ( class_exists( 'HalsteinCore_Button_Shortcode' ) ) {
			$link = apply_filters( 'woocommerce_loop_product_link', get_the_permalink(), halstein_core_woo_get_global_product() );

			$button_params = array(
				'link'          => $link,
				'text'          => esc_html__( 'View Details', 'halstein-core' ),
				'size'          => 'normal',
				'button_layout' => 'filled',
				'custom_class'  => 'qodef-yith-wcqv-link',
			);

			echo HalsteinCore_Button_Shortcode::call_shortcode( $button_params );
		}
	}
}
