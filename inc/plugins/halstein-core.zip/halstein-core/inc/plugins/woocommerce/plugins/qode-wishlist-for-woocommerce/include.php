<?php

include_once HALSTEIN_CORE_PLUGINS_PATH . '/woocommerce/plugins/qode-wishlist-for-woocommerce/helper.php';

if ( qode_framework_is_installed('qode-wishlist-for-woocommerce') ) {
	include_once HALSTEIN_CORE_PLUGINS_PATH . '/woocommerce/plugins/qode-wishlist-for-woocommerce/class-halsteincore-qode-wishlist-for-woocommerce.php';
}
