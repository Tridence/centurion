<?php

if ( ! function_exists( 'halstein_core_add_product_category_list_variation_info_on_image' ) ) {
	/**
	 * Function that add variation layout for this module
	 *
	 * @param array $variations
	 *
	 * @return array
	 */
	function halstein_core_add_product_category_list_variation_info_on_image( $variations ) {
		$variations['info-on-image'] = esc_html__( 'Info On Image', 'halstein-core' );

		return $variations;
	}

	add_filter( 'halstein_core_filter_product_category_list_layouts', 'halstein_core_add_product_category_list_variation_info_on_image' );
}
