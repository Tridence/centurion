<?php

if ( function_exists( 'halstein_woo_get_after_add_to_cart_template' ) ) {
	halstein_woo_get_after_add_to_cart_template();
}
