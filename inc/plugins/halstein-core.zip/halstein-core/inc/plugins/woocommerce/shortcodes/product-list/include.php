<?php

include_once HALSTEIN_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-list/class-halsteincore-product-list-shortcode.php';

foreach ( glob( HALSTEIN_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-list/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
