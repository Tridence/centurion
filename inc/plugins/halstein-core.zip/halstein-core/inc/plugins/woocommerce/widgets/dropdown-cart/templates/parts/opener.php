<a itemprop="url" class="qodef-m-opener" href="<?php echo esc_url( wc_get_cart_url() ); ?>">
	<span class="qodef-m-opener-label"><?php echo esc_html__( 'Cart', 'halstein-core' ); ?></span>
	<span class="qodef-m-opener-icon"><?php echo halstein_core_get_svg_icon( 'cart' ); ?></span>
</a>
