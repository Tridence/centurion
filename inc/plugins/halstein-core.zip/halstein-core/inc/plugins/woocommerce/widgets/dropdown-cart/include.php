<?php

include_once HALSTEIN_CORE_PLUGINS_PATH . '/woocommerce/widgets/dropdown-cart/class-halsteincore-woocommerce-dropdown-cart-widget.php';
