<?php

include_once HALSTEIN_CORE_PLUGINS_PATH . '/wpbakery/helper.php';
