<?php

include_once HALSTEIN_CORE_PLUGINS_PATH . '/twitter/shortcodes/twitter-list/widget/class-halsteincore-twitter-list-widget.php';
