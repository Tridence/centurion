<?php

include_once HALSTEIN_CORE_PLUGINS_PATH . '/twitter/shortcodes/twitter-list/class-halsteincore-twitter-list-shortcode.php';
