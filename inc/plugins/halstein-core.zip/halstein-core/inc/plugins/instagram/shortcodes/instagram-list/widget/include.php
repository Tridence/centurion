<?php

include_once HALSTEIN_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/widget/class-halsteincore-instagram-list-widget.php';
