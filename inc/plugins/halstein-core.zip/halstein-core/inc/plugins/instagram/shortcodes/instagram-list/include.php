<?php

include_once HALSTEIN_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/class-halsteincore-instagram-list-shortcode.php';
