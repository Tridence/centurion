<?php

include_once HALSTEIN_CORE_PLUGINS_PATH . '/instagram/helper.php';
