<?php

include_once HALSTEIN_CORE_SHORTCODES_PATH . '/vertical-split-slider/class-halsteincore-vertical-split-slider-shortcode.php';
