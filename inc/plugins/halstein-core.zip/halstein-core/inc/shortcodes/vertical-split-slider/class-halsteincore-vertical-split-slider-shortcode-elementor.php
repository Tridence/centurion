<?php

class HalsteinCore_Vertical_Split_Slider_Shortcode_Elementor extends HalsteinCore_Elementor_Widget_Base {

	public function __construct( array $data = [], $args = null ) {
		$this->set_shortcode_slug( 'halstein_vertical_split_slider' );

		parent::__construct( $data, $args );
	}
}

halstein_core_get_elementor_widgets_manager()->register( new HalsteinCore_Vertical_Split_Slider_Shortcode_Elementor() );
