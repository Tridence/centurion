<?php if ( ! empty( $item['slide_content_text'] ) ) : ?>
	<p class="qodef-m-text"><?php echo wp_kses( nl2br( $item['slide_content_text'] ), array( 'br' => array() ) ); ?></p>
<?php endif; ?>
