<?php
$slide_image_styles = $this_object->get_slide_image_styles( $item );
$slide_data         = $this_object->get_slide_data( $item );
$slide_classes      = 'ms-section ms-table';

if ( $is_responsive ) {
	$slide_data    = array();
	$slide_classes = '';
}
?>
<div class="qodef-m-slide-image <?php echo esc_attr( $slide_classes ); ?>" <?php echo qode_framework_get_inline_attrs( $slide_data ); ?> <?php qode_framework_inline_style( $slide_image_styles ); ?>></div>
