<?php if ( ! empty( $item['slide_content_title'] ) ) : ?>
	<<?php echo esc_attr( $item['slide_content_title_tag'] ); ?> class="qodef-m-title">
		<?php echo esc_html( $item['slide_content_title'] ); ?>
	</<?php echo esc_attr( $item['slide_content_title_tag'] ); ?>>
<?php endif; ?>
