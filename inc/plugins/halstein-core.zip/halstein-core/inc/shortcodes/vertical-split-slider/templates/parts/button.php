<?php
$button_params = array(
	'link'          => $item['slide_content_button_link'],
	'text'          => $item['slide_content_button_text'],
	'target'        => $item['slide_content_button_target'],
	'button_layout' => 'filled',
	'custom_class'  => 'qodef-m-button',
);

echo HalsteinCore_Button_Shortcode::call_shortcode( $button_params );
