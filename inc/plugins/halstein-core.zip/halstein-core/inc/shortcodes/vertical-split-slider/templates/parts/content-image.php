<?php
if ( ! empty( $item['slide_content_image'] ) ) :
	echo wp_get_attachment_image( $item['slide_content_image'], 'full', false, array( 'class' => 'qodef-m-image' ) );
endif;
