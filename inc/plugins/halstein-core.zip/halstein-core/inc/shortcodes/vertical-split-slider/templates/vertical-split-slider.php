<div <?php qode_framework_class_attribute( $holder_classes ); ?>>
	<div class="ms-left">
		<?php
		foreach ( $items as $key => $item ) :
			$params['item'] = $item;

			if ( 'image-left' === $item['slide_layout'] ) :
				halstein_core_template_part( 'shortcodes/vertical-split-slider', 'templates/parts/image', '', $params );
			else :
				?>
				<div class="qodef-m-slide-content ms-section ms-table" <?php echo qode_framework_get_inline_attrs( $slide_data ); ?>>
					<?php
					halstein_core_template_part( 'shortcodes/vertical-split-slider', 'templates/parts/content-image', '', $params );

					halstein_core_template_part( 'shortcodes/vertical-split-slider', 'templates/parts/title', '', $params );

					halstein_core_template_part( 'shortcodes/vertical-split-slider', 'templates/parts/text', '', $params );

					halstein_core_template_part( 'shortcodes/vertical-split-slider', 'templates/parts/button', '', $params );
					?>
				</div>
			<?php endif; ?>
		<?php endforeach; ?>
	</div><!-- .ms-left -->
	<div class="ms-right">
		<?php
		foreach ( $items as $key => $item ) :
			$params['item'] = $item;

			if ( 'image-right' === $item['slide_layout'] ) :
				halstein_core_template_part( 'shortcodes/vertical-split-slider', 'templates/parts/image', '', $params );
			else :
				?>
				<div class="qodef-m-slide-content ms-section ms-table">
					<?php
					halstein_core_template_part( 'shortcodes/vertical-split-slider', 'templates/parts/content-image', '', $params );

					halstein_core_template_part( 'shortcodes/vertical-split-slider', 'templates/parts/title', '', $params );

					halstein_core_template_part( 'shortcodes/vertical-split-slider', 'templates/parts/text', '', $params );

					halstein_core_template_part( 'shortcodes/vertical-split-slider', 'templates/parts/button', '', $params );
					?>
				</div>
			<?php endif; ?>
		<?php endforeach; ?>
	</div><!-- .ms-right -->
</div>
<div class="qodef-vertical-split-slider-responsive qodef-m">
	<?php
	foreach ( $items as $key => $item ) :
		$params['item']          = $item;
		$params['is_responsive'] = true;
		?>
		<div class="qodef-m-slide-content">
			<?php
			halstein_core_template_part( 'shortcodes/vertical-split-slider', 'templates/parts/content-image', '', $params );

			halstein_core_template_part( 'shortcodes/vertical-split-slider', 'templates/parts/title', '', $params );

			halstein_core_template_part( 'shortcodes/vertical-split-slider', 'templates/parts/text', '', $params );

			halstein_core_template_part( 'shortcodes/vertical-split-slider', 'templates/parts/button', '', $params );
			?>
		</div>
		<?php halstein_core_template_part( 'shortcodes/vertical-split-slider', 'templates/parts/image', '', $params ); ?>
	<?php endforeach; ?>
</div>
