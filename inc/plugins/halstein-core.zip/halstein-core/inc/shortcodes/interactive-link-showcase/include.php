<?php

include_once HALSTEIN_CORE_SHORTCODES_PATH . '/interactive-link-showcase/class-halsteincore-interactive-link-showcase-shortcode.php';

foreach ( glob( HALSTEIN_CORE_SHORTCODES_PATH . '/interactive-link-showcase/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
