<?php

include_once HALSTEIN_CORE_SHORTCODES_PATH . '/helper.php';
include_once HALSTEIN_CORE_SHORTCODES_PATH . '/class-halsteincore-shortcodes.php';
