<?php

include_once HALSTEIN_CORE_SHORTCODES_PATH . '/accordion/class-halsteincore-accordion-shortcode.php';
include_once HALSTEIN_CORE_SHORTCODES_PATH . '/accordion/class-halsteincore-accordion-child-shortcode.php';

foreach ( glob( HALSTEIN_CORE_SHORTCODES_PATH . '/accordion/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
