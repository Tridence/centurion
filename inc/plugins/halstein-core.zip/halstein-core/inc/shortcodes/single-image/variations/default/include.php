<?php

include_once HALSTEIN_CORE_SHORTCODES_PATH . '/single-image/variations/default/helper.php';
