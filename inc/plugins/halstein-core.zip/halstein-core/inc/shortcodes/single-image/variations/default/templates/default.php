<div <?php qode_framework_class_attribute( $holder_classes ); ?>>
	<?php halstein_core_template_part( 'shortcodes/single-image', 'templates/parts/image', '', $params ); ?>
</div>
