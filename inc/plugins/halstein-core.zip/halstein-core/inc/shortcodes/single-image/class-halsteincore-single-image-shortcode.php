<?php

if ( ! function_exists( 'halstein_core_add_single_image_shortcode' ) ) {
	/**
	 * Function that add shortcode into shortcodes list for registration
	 *
	 * @param $shortcodes array
	 *
	 * @return array
	 */
	function halstein_core_add_single_image_shortcode( $shortcodes ) {
		$shortcodes[] = 'HalsteinCore_Single_Image_Shortcode';

		return $shortcodes;
	}

	add_filter( 'halstein_core_filter_register_shortcodes', 'halstein_core_add_single_image_shortcode' );
}

if ( class_exists( 'HalsteinCore_Shortcode' ) ) {
	class HalsteinCore_Single_Image_Shortcode extends HalsteinCore_Shortcode {

		public function __construct() {
			$this->set_layouts( apply_filters( 'halstein_core_filter_single_image_layouts', array() ) );
			$this->set_extra_options( apply_filters( 'halstein_core_filter_single_image_extra_options', array() ) );

			parent::__construct();
		}

		public function map_shortcode() {
			$this->set_shortcode_path( HALSTEIN_CORE_SHORTCODES_URL_PATH . '/single-image' );
			$this->set_base( 'halstein_core_single_image' );
			$this->set_name( esc_html__( 'Single Image', 'halstein-core' ) );
			$this->set_description( esc_html__( 'Shortcode that adds image element', 'halstein-core' ) );
			$this->set_scripts(
				array(
					'jquery-magnific-popup' => array(
						'registered' => true,
					),
				)
			);
			$this->set_necessary_styles(
				array(
					'magnific-popup' => array(
						'registered' => true,
					),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'custom_class',
					'title'      => esc_html__( 'Custom Class', 'halstein-core' ),
				)
			);

			$options_map = halstein_core_get_variations_options_map( $this->get_layouts() );

			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'layout',
					'title'         => esc_html__( 'Layout', 'halstein-core' ),
					'options'       => $this->get_layouts(),
					'default_value' => $options_map['default_value'],
					'visibility'    => array( 'map_for_page_builder' => $options_map['visibility'] ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'image',
					'name'       => 'image',
					'title'      => esc_html__( 'Image', 'halstein-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'retina_scaling',
					'title'         => esc_html__( 'Enable Retina Scaling', 'halstein-core' ),
					'description'   => esc_html__( 'Image uploaded should be two times the height.', 'halstein-core' ),
					'options'       => halstein_core_get_select_type_options_pool( 'yes_no' ),
					'default_value' => '',
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'images_proportion',
					'default_value' => 'full',
					'title'         => esc_html__( 'Image Proportions', 'halstein-core' ),
					'options'       => halstein_core_get_select_type_options_pool( 'list_image_dimension', false ),
					'dependency'    => array(
						'hide' => array(
							'retina_scaling' => array(
								'values'        => 'yes',
								'default_value' => '',
							),
						),
					),
				)
			);
			$this->set_option(
				array(
					'field_type'  => 'text',
					'name'        => 'custom_image_width',
					'title'       => esc_html__( 'Custom Image Width', 'halstein-core' ),
					'description' => esc_html__( 'Enter image width in px', 'halstein-core' ),
					'dependency'  => array(
						'show' => array(
							'images_proportion' => array(
								'values'        => 'custom',
								'default_value' => 'full',
							),
						),
					),
				)
			);
			$this->set_option(
				array(
					'field_type'  => 'text',
					'name'        => 'custom_image_height',
					'title'       => esc_html__( 'Custom Image Height', 'halstein-core' ),
					'description' => esc_html__( 'Enter image height in px', 'halstein-core' ),
					'dependency'  => array(
						'show' => array(
							'images_proportion' => array(
								'values'        => 'custom',
								'default_value' => 'full',
							),
						),
					),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'select',
					'name'       => 'image_action',
					'title'      => esc_html__( 'Image Action', 'halstein-core' ),
					'options'    => array(
						''            => esc_html__( 'No Action', 'halstein-core' ),
						'open-popup'  => esc_html__( 'Open Popup', 'halstein-core' ),
						'custom-link' => esc_html__( 'Custom Link', 'halstein-core' ),
					),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'link',
					'title'      => esc_html__( 'Custom Link', 'halstein-core' ),
					'dependency' => array(
						'show' => array(
							'image_action' => array(
								'values'        => array( 'custom-link' ),
								'default_value' => '',
							),
						),
					),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'target',
					'title'         => esc_html__( 'Custom Link Target', 'halstein-core' ),
					'options'       => halstein_core_get_select_type_options_pool( 'link_target' ),
					'default_value' => '_self',
					'dependency'    => array(
						'show' => array(
							'image_action' => array(
								'values'        => 'custom-link',
								'default_value' => '',
							),
						),
					),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'parallax_item',
					'title'         => esc_html__( 'Enable Parallax Item', 'halstein-core' ),
					'options'       => halstein_core_get_select_type_options_pool( 'yes_no' ),
					'default_value' => '',
				)
			);
			$this->set_option(
				array(
					'field_type' => 'select',
					'name'       => 'appear_animation',
					'title'      => esc_html__( 'Enable Appear Animation', 'halstein-core' ),
					'options'    => halstein_core_get_select_type_options_pool( 'no_yes', false ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'select',
					'name'       => 'zoom_scroll',
					'title'      => esc_html__( 'Enable Zoom Scroll', 'halstein-core' ),
					'options'    => halstein_core_get_select_type_options_pool( 'no_yes', false ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'select',
					'name'       => 'appear_animation_direction',
					'title'      => esc_html__( 'Appear Animation Direction', 'halstein-core' ),
					'options'    => array(
						'from-left'  => esc_html__( 'From Left', 'halstein-core' ),
						'from-right' => esc_html__( 'From Right', 'halstein-core' ),
					),
					'dependency' => array(
						'show' => array(
							'appear_animation' => array(
								'values'        => 'yes',
								'default_value' => '',
							),
						),
					),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'select',
					'name'       => 'fullheight',
					'title'      => esc_html__( 'Fit Height To Screen', 'halstein-core' ),
					'options'    => halstein_core_get_select_type_options_pool( 'no_yes', false ),
				)
			);

			$this->map_extra_options();
		}

		public static function call_shortcode( $params ) {
			$html = qode_framework_call_shortcode( 'halstein_core_single_image', $params );
			$html = str_replace( "\n", '', $html );

			return $html;
		}

		public function load_assets() {

			if ( isset( $atts['image_action'] ) && 'open-popup' === $atts['image_action'] ) {
				wp_enqueue_style( 'magnific-popup' );
				wp_enqueue_script( 'jquery-magnific-popup' );
			}
		}

		public function render( $options, $content = null ) {
			parent::render( $options );
			$atts = $this->get_atts();

			$atts['holder_classes']       = $this->get_holder_classes( $atts );
			$atts['image_holder_classes'] = $this->get_image_holder_classes( $atts );
			$atts['image_params']         = $this->generate_image_params( $atts );

			return halstein_core_get_template_part( 'shortcodes/single-image', 'variations/' . $atts['layout'] . '/templates/' . $atts['layout'], '', $atts );
		}

		private function get_holder_classes( $atts ) {
			$holder_classes = $this->init_holder_classes();

			$holder_classes[] = 'qodef-single-image';
			$holder_classes[] = ! empty( $atts['layout'] ) ? 'qodef-layout--' . $atts['layout'] : '';
			$holder_classes[] = ! empty( $atts['parallax_item'] ) && ( 'yes' === $atts['parallax_item'] ) ? 'qodef-parallax-item' : '';
			$holder_classes[] = ( 'yes' === $atts['retina_scaling'] ) ? 'qodef--retina' : '';
			$holder_classes[] = ! empty( $atts['appear_animation'] ) && ( 'yes' === $atts['appear_animation'] ) ? 'qodef--has-appear' : '';
			$holder_classes[] = ! empty( $atts['appear_animation_direction'] ) ? 'qodef-direction--' . $atts['appear_animation_direction'] : '';
			$holder_classes[] = ( 'yes' === $atts['fullheight'] ) ? 'qodef--fullheight' : '';

			return implode( ' ', $holder_classes );
		}

		public function get_image_holder_classes( $atts ) {
			$item_classes = array();

			$item_classes[] = 'qodef-m-image';
			$item_classes[] = ! empty( $atts['zoom_scroll'] ) && ( 'yes' === $atts['zoom_scroll'] ) ? 'qodef-zoom-scroll' : '';

			return $item_classes;
		}

		private function generate_image_params( $atts ) {
			$image = array();

			if ( ! empty( $atts['image'] ) ) {
				$id = $atts['image'];

				$image['image_id'] = intval( $id );
				$image_original    = wp_get_attachment_image_src( $id, 'full' );
				$image['url']      = $image_original[0];
				$image['alt']      = get_post_meta( $id, '_wp_attachment_image_alt', true );

				$images_proportion = trim( $atts['images_proportion'] );
				preg_match_all( '/\d+/', $images_proportion, $matches ); /* check if numeral width and height are entered */
				if ( in_array( $images_proportion, array( 'thumbnail', 'thumb', 'medium', 'large', 'full' ), true ) ) {
					$image['images_proportion'] = $images_proportion;
				} elseif ( ! empty( $matches[0] ) ) {
					$image['images_proportion'] = array(
						$matches[0][0],
						$matches[0][1],
					);
				} else {
					$image['images_proportion'] = 'full';
				}
			}

			return $image;
		}
	}
}
