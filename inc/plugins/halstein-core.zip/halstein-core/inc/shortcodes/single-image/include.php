<?php

include_once HALSTEIN_CORE_SHORTCODES_PATH . '/single-image/class-halsteincore-single-image-shortcode.php';

foreach ( glob( HALSTEIN_CORE_SHORTCODES_PATH . '/single-image/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
