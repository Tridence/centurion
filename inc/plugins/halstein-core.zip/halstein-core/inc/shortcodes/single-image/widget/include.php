<?php

include_once HALSTEIN_CORE_SHORTCODES_PATH . '/single-image/widget/class-halsteincore-single-image-widget.php';
