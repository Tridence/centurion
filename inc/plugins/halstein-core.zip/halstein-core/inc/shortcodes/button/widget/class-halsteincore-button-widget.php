<?php

if ( ! function_exists( 'halstein_core_add_button_widget' ) ) {
	/**
	 * Function that add widget into widgets list for registration
	 *
	 * @param array $widgets
	 *
	 * @return array
	 */
	function halstein_core_add_button_widget( $widgets ) {
		$widgets[] = 'HalsteinCore_Button_Widget';

		return $widgets;
	}

	add_filter( 'halstein_core_filter_register_widgets', 'halstein_core_add_button_widget' );
}

if ( class_exists( 'QodeFrameworkWidget' ) ) {
	class HalsteinCore_Button_Widget extends QodeFrameworkWidget {

		public function map_widget() {
			$widget_mapped = $this->import_shortcode_options(
				array(
					'shortcode_base' => 'halstein_core_button',
				)
			);
			if ( $widget_mapped ) {
				$this->set_base( 'halstein_core_button' );
				$this->set_name( esc_html__( 'Halstein Button', 'halstein-core' ) );
				$this->set_description( esc_html__( 'Add a button element into widget areas', 'halstein-core' ) );
			}
		}

		public function render( $atts ) {
			echo HalsteinCore_Button_Shortcode::call_shortcode( $atts ); // XSS OK
		}
	}
}
