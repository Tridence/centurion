<?php

include_once HALSTEIN_CORE_SHORTCODES_PATH . '/button/variations/textual/helper.php';
