<?php

if ( ! function_exists( 'halstein_core_add_button_variation_filled_two' ) ) {
	/**
	 * Function that add variation layout for this module
	 *
	 * @param array $variations
	 *
	 * @return array
	 */
	function halstein_core_add_button_variation_filled_two( $variations ) {
		$variations['filled-two'] = esc_html__( 'Filled Two', 'halstein-core' );

		return $variations;
	}

	add_filter( 'halstein_core_filter_button_layouts', 'halstein_core_add_button_variation_filled_two' );
}
