<?php if ( ! empty( $number ) ) { ?>
	<span class="qodef-m-number" <?php qode_framework_inline_style( $number_styles ); ?>><?php echo esc_html( $number ); ?></span>
<?php } ?>
