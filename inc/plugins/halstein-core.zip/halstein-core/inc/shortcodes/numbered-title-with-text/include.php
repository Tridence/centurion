<?php

include_once HALSTEIN_CORE_SHORTCODES_PATH . '/numbered-title-with-text/class-halsteincore-numbered-title-with-text-shortcode.php';

foreach ( glob( HALSTEIN_CORE_SHORTCODES_PATH . '/numbered-title-with-text/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
