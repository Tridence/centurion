<div <?php qode_framework_class_attribute( $holder_classes ); ?>>
	<div class="qodef-m-content">
		<?php halstein_core_template_part( 'shortcodes/numbered-title-with-text', 'templates/parts/number', '', $params ); ?>
		<?php halstein_core_template_part( 'shortcodes/numbered-title-with-text', 'templates/parts/title', '', $params ); ?>
		<?php halstein_core_template_part( 'shortcodes/numbered-title-with-text', 'templates/parts/text', '', $params ); ?>
	</div>
</div>
