<?php

if ( ! function_exists( 'halstein_core_add_numbered_title_with_text_variation_standard' ) ) {
	/**
	 * Function that add variation layout for this module
	 *
	 * @param array $variations
	 *
	 * @return array
	 */
	function halstein_core_add_numbered_title_with_text_variation_standard( $variations ) {
		$variations['standard'] = esc_html__( 'Standard', 'halstein-core' );

		return $variations;
	}

	add_filter( 'halstein_core_filter_numbered_title_with_text_layouts', 'halstein_core_add_numbered_title_with_text_variation_standard' );
}
