<li class="qodef-m-list-item" <?php qode_framework_inline_style( $item_styles ); ?>>
	<?php
	// include item marker
	halstein_core_template_part( 'shortcodes/list-items', 'templates/parts/marker', '', $params );

	// include item title
	halstein_core_template_part( 'shortcodes/list-items', 'templates/parts/title', '', $params );

	// include item text
	halstein_core_template_part( 'shortcodes/list-items', 'templates/parts/text', '', $params );
	?>
</li>
