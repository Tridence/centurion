<?php

include_once HALSTEIN_CORE_SHORTCODES_PATH . '/list-items/variations/bulleted-list/bulleted-list.php';
