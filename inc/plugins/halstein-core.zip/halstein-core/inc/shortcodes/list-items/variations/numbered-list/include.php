<?php

include_once HALSTEIN_CORE_SHORTCODES_PATH . '/list-items/variations/numbered-list/numbered-list.php';
