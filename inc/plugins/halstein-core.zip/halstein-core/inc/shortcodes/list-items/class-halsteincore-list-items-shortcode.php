<?php

if ( ! function_exists( 'halstein_core_add_list_items_shortcode' ) ) {
	/**
	 * Function that isadding shortcode into shortcodes list for registration
	 *
	 * @param array $shortcodes - Array of registered shortcodes
	 *
	 * @return array
	 */
	function halstein_core_add_list_items_shortcode( $shortcodes ) {
		$shortcodes[] = 'HalsteinCore_List_Items_Shortcode';

		return $shortcodes;
	}

	add_filter( 'halstein_core_filter_register_shortcodes', 'halstein_core_add_list_items_shortcode', 9 );
}

if ( class_exists( 'HalsteinCore_Shortcode' ) ) {
	class HalsteinCore_List_Items_Shortcode extends HalsteinCore_Shortcode {

		public function __construct() {
			$this->set_layouts( apply_filters( 'halstein_core_filter_list_items_layouts', array() ) );

			$options_map   = halstein_core_get_variations_options_map( $this->get_layouts() );
			$default_value = $options_map['default_value'];

			$this->set_extra_options( apply_filters( 'halstein_core_filter_list_items_extra_options', array(), $default_value ) );

			parent::__construct();
		}

		public function map_shortcode() {
			$this->set_shortcode_path( HALSTEIN_CORE_SHORTCODES_URL_PATH . '/list-items' );
			$this->set_base( 'halstein_core_list_items' );
			$this->set_name( esc_html__( 'List Items', 'halstein-core' ) );
			$this->set_description( esc_html__( 'Shortcode that displays list items with provided parameters', 'halstein-core' ) );
			$this->set_category( esc_html__( 'Halstein Core', 'halstein-core' ) );
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'custom_class',
					'title'      => esc_html__( 'Custom Class', 'halstein-core' ),
				)
			);

			$options_map = halstein_core_get_variations_options_map( $this->get_layouts() );

			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'layout',
					'title'         => esc_html__( 'Layout', 'halstein-core' ),
					'options'       => $this->get_layouts(),
					'default_value' => $options_map['default_value'],
					'visibility'    => array(
						'map_for_page_builder' => $options_map['visibility'],
					),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'counter_set',
					'title'      => esc_html__( 'Counter Set', 'halstein-core' ),
					'dependency' => array(
						'show' => array(
							'layout' => array(
								'values'        => 'numbered-list',
								'default_value' => '',
							),
						),
					),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'select',
					'name'       => 'skin',
					'title'      => esc_html__( 'Skin', 'halstein-core' ),
					'options'    => array(
						''      => esc_html__( 'Default', 'halstein-core' ),
						'light' => esc_html__( 'Light', 'halstein-core' ),
					),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'items_title_tag',
					'title'         => esc_html__( 'Items Title Tag', 'halstein-core' ),
					'options'       => halstein_core_get_select_type_options_pool( 'title_tag', false ),
					'default_value' => 'p',
					'group'         => esc_html__( 'Items Style', 'halstein-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'color',
					'name'       => 'items_title_color',
					'title'      => esc_html__( 'Items Title Color', 'halstein-core' ),
					'group'      => esc_html__( 'Items Style', 'halstein-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'items_text_margin_top',
					'title'      => esc_html__( 'Items Text Margin Top', 'halstein-core' ),
					'group'      => esc_html__( 'Items Style', 'halstein-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'items_margin_bottom',
					'title'      => esc_html__( 'Items Margin Bottom', 'halstein-core' ),
					'group'      => esc_html__( 'Items Style', 'halstein-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'items_column_gap',
					'title'      => esc_html__( 'Items Column Gap', 'halstein-core' ),
					'group'      => esc_html__( 'Items Style', 'halstein-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'repeater',
					'name'       => 'children',
					'title'      => esc_html__( 'Tab Items', 'halstein-core' ),
					'items'      => array(
						array(
							'field_type'    => 'text',
							'name'          => 'item_title',
							'title'         => esc_html__( 'Title', 'halstein-core' ),
							'default_value' => esc_html__( 'List Item Title', 'halstein-core' ),
						),
						array(
							'field_type'    => 'text',
							'name'          => 'item_text',
							'title'         => esc_html__( 'Text', 'halstein-core' ),
							'default_value' => esc_html__( 'List Item Text', 'halstein-core' ),
						),
						array(
							'field_type' => 'text',
							'name'       => 'item_link',
							'title'      => esc_html__( 'Link', 'halstein-core' ),
						),
						array(
							'field_type'    => 'select',
							'name'          => 'item_target',
							'title'         => esc_html__( 'Target', 'halstein-core' ),
							'options'       => halstein_core_get_select_type_options_pool( 'link_target' ),
							'default_value' => '_self',
						),
						array(
							'field_type' => 'color',
							'name'       => 'item_marker_color',
							'title'      => esc_html__( 'Item Marker Color', 'halstein-core' ),
						),
					),
				)
			);
			$this->map_extra_options();
		}

		public static function call_shortcode( $params ) {
			$html = qode_framework_call_shortcode( 'halstein_core_list_items', $params );
			$html = str_replace( "\n", '', $html );

			return $html;
		}

		public function render( $options, $content = null ) {
			parent::render( $options );

			$atts = $this->get_atts();

			$atts['holder_classes']      = $this->get_holder_classes( $atts );
			$atts['items']               = $this->parse_repeater_items( $atts['children'] );
			$atts['items_holder_styles'] = $this->get_items_holder_styles( $atts );
			$atts['item_styles']         = $this->get_item_styles( $atts );
			$atts['list_tag']            = $this->get_list_tag( $atts );
			$atts['this_shortcode']      = $this;

			return halstein_core_get_template_part( 'shortcodes/list-items', 'templates/content', '', $atts );
		}

		private function get_holder_classes( $atts ) {
			$holder_classes = $this->init_holder_classes();

			$holder_classes[] = 'qodef-list-items';
			$holder_classes[] = ! empty( $atts['layout'] ) ? 'qodef-layout--' . $atts['layout'] : '';
			$holder_classes[] = isset( $atts['skin'] ) && ! empty( $atts['skin'] ) ? 'qodef-skin--' . $atts['skin'] : '';

			return implode( ' ', $holder_classes );
		}

		private function get_items_holder_styles( $atts ) {
			$styles = array();

			if ( ! empty( $atts['counter_set'] ) ) {
				$styles[] = 'counter-reset: counter ' . intval( $atts['counter_set'] );
			}

			return $styles;
		}

		private function get_item_styles( $atts ) {
			$styles = array();

			if ( '' !== $atts['items_column_gap'] ) {
				if ( qode_framework_string_ends_with_space_units( $atts['items_column_gap'] ) ) {
					$styles[] = 'column-gap: ' . $atts['items_column_gap'];
				} else {
					$styles[] = 'column-gap: ' . intval( $atts['items_column_gap'] ) . 'px';
				}
			}

			if ( '' !== $atts['items_margin_bottom'] ) {
				if ( qode_framework_string_ends_with_space_units( $atts['items_margin_bottom'] ) ) {
					$styles[] = 'margin-bottom: ' . $atts['items_margin_bottom'];
				} else {
					$styles[] = 'margin-bottom: ' . intval( $atts['items_margin_bottom'] ) . 'px';
				}
			}

			return $styles;
		}

		public function get_marker_styles( $item ) {
			$styles = array();

			if ( ! empty( $item['item_marker_color'] ) ) {
				$styles[] = 'color: ' . $item['item_marker_color'];
			}

			return $styles;
		}

		public function get_title_styles( $atts ) {
			$styles = array();

			if ( ! empty( $atts['items_title_color'] ) ) {
				$styles[] = 'color: ' . $atts['items_title_color'];
			}

			return $styles;
		}

		public function get_text_styles( $atts ) {
			$styles = array();

			if ( '' !== $atts['items_text_margin_top'] ) {
				if ( qode_framework_string_ends_with_space_units( $atts['items_text_margin_top'] ) ) {
					$styles[] = 'margin-top: ' . $atts['items_text_margin_top'];
				} else {
					$styles[] = 'margin-top: ' . intval( $atts['items_text_margin_top'] ) . 'px';
				}
			}

			return $styles;
		}

		private function get_list_tag( $atts ) {
			return ! empty( $atts['layout'] ) && 'numbered-list' === $atts['layout'] ? 'ol' : 'ul';
		}
	}
}
