<?php if ( ! empty( $item['item_title'] ) ) : ?>
	<<?php echo esc_attr( $items_title_tag ); ?> class="qodef-m-list-item-title" <?php qode_framework_inline_style( $this_shortcode->get_title_styles( $params ) ); ?>>
		<?php if ( ! empty( $item['item_link'] ) ) : ?>
			<a class="qodef-m-list-link" itemprop="url" href="<?php echo esc_url( $item['item_link'] ); ?>" target="<?php echo esc_attr( $item['item_target'] ); ?>">
		<?php endif; ?>
		<?php echo esc_html( $item['item_title'] ); ?>
		<?php if ( ! empty( $item['item_link'] ) ) : ?>
			</a>
		<?php endif; ?>
	</<?php echo esc_attr( $items_title_tag ); ?>>
<?php endif; ?>
