<span class="qodef-m-list-item-marker" <?php qode_framework_inline_style( $this_shortcode->get_marker_styles( $item ) ); ?>>
	<?php
	// include item marker
	halstein_core_render_svg_icon( $layout . '-marker', 'qodef-m-marker' );
	?>
</span>
