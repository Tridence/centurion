<div <?php qode_framework_class_attribute( $holder_classes ); ?>>
	<?php if ( ! empty( $items ) ) : ?>
		<?php echo '<' . esc_html( $list_tag ); ?> class="qodef-m-list" <?php qode_framework_inline_style( $items_holder_styles ); ?>>
		<?php foreach ( $items as $item ) : ?>
			<?php $params['item'] = $item; ?>
			<?php
			// include items content
			halstein_core_template_part( 'shortcodes/list-items', 'variations/' . $layout . '/templates/' . $layout, 'content', $params );
			?>
		<?php endforeach; ?>
		<?php echo '</' . esc_html( $list_tag ); ?>>
	<?php endif; ?>
</div>
