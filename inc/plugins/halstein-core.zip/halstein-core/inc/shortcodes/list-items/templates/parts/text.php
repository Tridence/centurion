<?php if ( ! empty( $item['item_text'] ) ) : ?>
	<p class="qodef-m-list-item-text" <?php qode_framework_inline_style( $this_shortcode->get_text_styles( $params ) ); ?>>
		<?php echo esc_html( $item['item_text'] ); ?>
	</p>
<?php endif; ?>
