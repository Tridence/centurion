<?php

include_once HALSTEIN_CORE_SHORTCODES_PATH . '/list-items/class-halsteincore-list-items-shortcode.php';

foreach ( glob( HALSTEIN_CORE_SHORTCODES_PATH . '/list-items/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
