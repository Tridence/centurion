<?php if ( 'custom-icon' === $icon_type && ! empty( $custom_icon ) ) : ?>
	<div class="qodef-icon-holder">
		<?php echo wp_get_attachment_image( $custom_icon, 'full' ); ?>
	</div>
<?php endif; ?>
