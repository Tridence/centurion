<?php

include_once HALSTEIN_CORE_SHORTCODES_PATH . '/icon-list-item/widget/class-halsteincore-icon-list-item-widget.php';
