<?php

include_once HALSTEIN_CORE_SHORTCODES_PATH . '/icon-list-item/class-halsteincore-icon-list-item-shortcode.php';
