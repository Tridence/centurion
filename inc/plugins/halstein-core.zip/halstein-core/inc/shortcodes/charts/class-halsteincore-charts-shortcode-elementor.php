<?php

class HalsteinCore_Charts_Shortcode_Elementor extends HalsteinCore_Elementor_Widget_Base {

	function __construct( array $data = [], $args = null ) {
		$this->set_shortcode_slug( 'halstein_core_charts' );

		parent::__construct( $data, $args );
	}
}

halstein_core_get_elementor_widgets_manager()->register( new HalsteinCore_Charts_Shortcode_Elementor() );
