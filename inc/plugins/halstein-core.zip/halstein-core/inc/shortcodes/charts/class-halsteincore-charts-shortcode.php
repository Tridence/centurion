<?php

if ( ! function_exists( 'halstein_core_add_charts_shortcode' ) ) {
	/**
	 * Function that add shortcode into shortcodes list for registration
	 *
	 * @param array $shortcodes
	 *
	 * @return array
	 */
	function halstein_core_add_charts_shortcode( $shortcodes ) {
		$shortcodes[] = 'HalsteinCore_Charts_Shortcode';

		return $shortcodes;
	}

	add_filter( 'halstein_core_filter_register_shortcodes', 'halstein_core_add_charts_shortcode' );
}

if ( class_exists( 'HalsteinCore_Shortcode' ) ) {
	class HalsteinCore_Charts_Shortcode extends HalsteinCore_Shortcode {

		public function map_shortcode() {
			$this->set_shortcode_path( HALSTEIN_CORE_SHORTCODES_URL_PATH . '/charts' );
			$this->set_base( 'halstein_core_charts' );
			$this->set_name( esc_html__( 'Pie and Donut Charts', 'halstein-core' ) );
			$this->set_description( esc_html__( 'Shortcode that displays charts with provided parameters', 'halstein-core' ) );
			$this->set_scripts(
				array(
					'chart' => array(
						'registered' => false,
						'url'        => HALSTEIN_CORE_ASSETS_URL_PATH . '/plugins/charts/Chart.min.js',
						'dependency' => array( 'jquery' ),
					),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'custom_class',
					'title'      => esc_html__( 'Custom Class', 'halstein-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'repeater',
					'name'       => 'children',
					'title'      => esc_html__( 'Values', 'halstein-core' ),
					'items'      => array(
						array(
							'field_type'    => 'number',
							'name'          => 'item_data_value',
							'title'         => esc_html__( 'Data Value', 'halstein-core' ),
							'default_value' => 20,
						),
						array(
							'field_type'    => 'text',
							'name'          => 'item_data_label',
							'title'         => esc_html__( 'Data Label', 'halstein-core' ),
							'default_value' => esc_html__( 'Label', 'halstein-core' ),
						),
						array(
							'field_type'    => 'color',
							'name'          => 'item_background_color',
							'title'         => esc_html__( 'Background Color', 'halstein-core' ),
							'default_value' => '#14203b',
						),
						array(
							'field_type'    => 'color',
							'name'          => 'item_hover_background_color',
							'title'         => esc_html__( 'Hover Background Color', 'halstein-core' ),
							'default_value' => '#0f182d',
						),
					),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'select',
					'name'       => 'chart_type',
					'title'      => esc_html__( 'Chart Type', 'halstein-core' ),
					'options'    => array(
						'pie'      => esc_html__( 'Pie', 'halstein-core' ),
						'doughnut' => esc_html__( 'Doughnut', 'halstein-core' ),
					),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'color',
					'name'       => 'shadow_background_color',
					'title'      => esc_html__( 'Shadow Background Color', 'halstein-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'select',
					'name'       => 'enable_chart_legend',
					'title'      => esc_html__( 'Enable Chart Legend', 'halstein-core' ),
					'options'    => halstein_core_get_select_type_options_pool( 'yes_no', false ),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'color',
					'name'          => 'legend_label_color',
					'title'         => esc_html__( 'Legend Label Color', 'halstein-core' ),
					'default_value' => '#14203b',
					'dependency'    => array(
						'show' => array(
							'enable_chart_legend' => array(
								'values'        => 'yes',
								'default_value' => 'yes',
							),
						),
					),
				)
			);
		}

		public function load_assets() {
			wp_enqueue_script( 'chart' );
		}

		public static function call_shortcode( $params ) {
			$html = qode_framework_call_shortcode( 'halstein_core_charts', $params );
			$html = str_replace( "\n", '', $html );

			return $html;
		}

		public function render( $options, $content = null ) {
			parent::render( $options );
			$atts = $this->get_atts();

			$atts['holder_classes']       = $this->get_holder_classes( $atts );
			$atts['items']                = $this->parse_repeater_items( $atts['children'] );
			$atts['data_attrs']           = $this->get_data_attrs( $atts['items'], $atts );
			$atts['canvas_holder_styles'] = $this->get_canvas_holder_styles( $atts );
			$atts['legend_label_styles']  = $this->get_legend_label_styles( $atts );

			return halstein_core_get_template_part( 'shortcodes/charts', 'templates/charts', '', $atts );
		}

		private function get_holder_classes( $atts ) {
			$holder_classes = $this->init_holder_classes();

			$holder_classes[] = 'qodef-charts';

			return implode( ' ', $holder_classes );
		}

		private function get_data_attrs( $items, $atts ) {
			$data = array();
			$temp = array();

			foreach ( $items as $key => $value ) {
				$temp['data-values'][]                  = ! empty( $value['item_data_value'] ) ? $value['item_data_value'] : 0;
				$temp['data-labels'][]                  = ! empty( $value['item_data_label'] ) ? $value['item_data_label'] : 'label-' . ( $key + 1 );
				$temp['data-background-colors'][]       = ! empty( $value['item_background_color'] ) ? $value['item_background_color'] : '#14203b';
				$temp['data-hover-background-colors'][] = ! empty( $value['item_hover_background_color'] ) ? $value['item_hover_background_color'] : '#0f182d';
			}

			$temp['data-type']               = 'pie' === $atts['chart_type'];
			$temp['data-legend-label-color'] = ! empty( $atts['legend_label_color'] ) ? $atts['legend_label_color'] : '';

			foreach ( $temp as $key => $value ) {
				if ( is_array( $value ) || is_bool( $value ) ) {
					$data[ $key ] = json_encode( $value );
				} else {
					$data[ $key ] = $value;
				}
			}

			return $data;
		}

		public function get_legend_label_styles( $atts ) {
			$styles = array();

			if ( ! empty( $atts['legend_label_color'] ) ) {
				$styles[] = 'color: ' . $atts['legend_label_color'];
			}

			return $styles;
		}

		public function get_canvas_holder_styles( $atts ) {
			$styles = array();

			if ( ! empty( $atts['shadow_background_color'] ) ) {
				$styles[] = 'color: ' . $atts['shadow_background_color'];
			}

			return $styles;
		}
	}
}
