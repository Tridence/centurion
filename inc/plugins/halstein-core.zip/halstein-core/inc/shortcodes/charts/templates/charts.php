<div <?php qode_framework_class_attribute( $holder_classes ); ?> <?php qode_framework_inline_attrs( $data_attrs, true ); ?>>
	<div class="qodef-m-inner">
		<div class="qodef-m-canvas-holder" <?php qode_framework_inline_style( $canvas_holder_styles ); ?>>
			<div class="qodef-m-canvas">
				<canvas></canvas>
			</div>
		</div>
		<?php if ( 'yes' === $enable_chart_legend ) : ?>
			<div class="qodef-m-legend">
				<?php foreach ( $items as $item ) : ?>
					<div class="qodef-m-legend-item">
						<?php if ( ! empty( $item['item_data_label'] ) ) : ?>
							<span class="qodef-m-legend-icon" <?php qode_framework_inline_style( array( 'background-color: ' . $item['item_background_color'] ) ); ?>></span>
							<span class="qodef-m-legend-label" <?php qode_framework_inline_style( $legend_label_styles ); ?>><?php echo esc_html( $item['item_data_label'] ); ?></span>
						<?php endif; ?>
					</div>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
	</div>
</div>
