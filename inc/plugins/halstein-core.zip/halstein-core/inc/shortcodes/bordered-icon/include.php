<?php

include_once HALSTEIN_CORE_SHORTCODES_PATH . '/bordered-icon/class-halsteincore-bordered-icon-shortcode.php';
