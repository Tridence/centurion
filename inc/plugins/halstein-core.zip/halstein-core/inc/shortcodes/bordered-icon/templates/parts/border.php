<div class="qodef-m-border" <?php qode_framework_inline_style( $border_styles ); ?>>
	<?php halstein_core_render_svg_icon( 'border' ); ?>
</div>
