<div <?php qode_framework_class_attribute( $holder_classes ); ?>>
	<div class="qodef-m-inner">
		<?php halstein_core_template_part( 'shortcodes/bordered-icon', 'templates/parts/border', '', $params ); ?>
		<?php halstein_core_template_part( 'shortcodes/bordered-icon', 'templates/parts/' . $icon_source, '', $params ); ?>
		<?php halstein_core_template_part( 'shortcodes/bordered-icon', 'templates/parts/link', '', $params ); ?>
	</div>
</div>
