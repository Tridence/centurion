<?php if ( ! empty( $image ) ) : ?>
	<div class="qodef-m-icon">
		<?php echo wp_get_attachment_image( $image, 'full' ); ?>
	</div>
<?php endif; ?>
