<?php if ( ! empty( $svg_path ) ) : ?>
	<div class="qodef-m-icon">
		<?php echo qode_framework_wp_kses_html( 'html', $svg_path ); ?>
	</div>
<?php endif; ?>
