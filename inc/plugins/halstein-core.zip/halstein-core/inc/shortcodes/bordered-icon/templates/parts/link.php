<?php if ( ! empty( $link ) ) : ?>
	<a itemprop="url" class="qodef-m-link" href="<?php echo esc_url( $link ); ?>" target="<?php echo esc_attr( $link_target ); ?>"></a>
<?php endif; ?>
