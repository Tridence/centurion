<?php

if ( ! function_exists( 'halstein_core_add_bordered_icon_shortcode' ) ) {
	/**
	 * Function that add shortcode into shortcodes list for registration
	 *
	 * @param array $shortcodes
	 *
	 * @return array
	 */
	function halstein_core_add_bordered_icon_shortcode( $shortcodes ) {
		$shortcodes[] = 'HalsteinCore_Bordered_Icon_Shortcode';

		return $shortcodes;
	}

	add_filter( 'halstein_core_filter_register_shortcodes', 'halstein_core_add_bordered_icon_shortcode' );
}

if ( class_exists( 'HalsteinCore_Shortcode' ) ) {
	class HalsteinCore_Bordered_Icon_Shortcode extends HalsteinCore_Shortcode {

		public function map_shortcode() {
			$this->set_shortcode_path( HALSTEIN_CORE_SHORTCODES_URL_PATH . '/bordered-icon' );
			$this->set_base( 'halstein_core_bordered_icon' );
			$this->set_name( esc_html__( 'Bordered Icon', 'halstein-core' ) );
			$this->set_description( esc_html__( 'Shortcode that adds bordered icon element', 'halstein-core' ) );
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'custom_class',
					'title'      => esc_html__( 'Custom Class', 'halstein-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'icon_source',
					'title'         => esc_html__( 'Icon Source', 'halstein-core' ),
					'options'       => array(
						'image' => esc_html__( 'Upload Image', 'halstein-core' ),
						'svg'   => esc_html__( 'SVG Path', 'halstein-core' ),
					),
					'default_value' => 'image',
				)
			);
			$this->set_option(
				array(
					'field_type' => 'image',
					'name'       => 'image',
					'title'      => esc_html__( 'Image', 'halstein-core' ),
					'multiple'   => 'no',
					'dependency' => array(
						'show' => array(
							'icon_source' => array(
								'values'        => 'image',
								'default_value' => 'image',
							),
						),
					),
				)
			);
			$this->set_option(
				array(
					'field_type'  => 'textarea',
					'name'        => 'svg_path',
					'title'       => esc_html__( 'SVG Path', 'halstein-core' ),
					'description' => esc_html__( 'When inserting an SVG path, remove the id attribute.', 'halstein-core' ),
					'dependency'  => array(
						'show' => array(
							'icon_source' => array(
								'values'        => 'svg',
								'default_value' => 'image',
							),
						),
					),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'select',
					'name'       => 'icon_action',
					'title'      => esc_html__( 'Icon Action', 'halstein-core' ),
					'options'    => array(
						''            => esc_html__( 'No Action', 'halstein-core' ),
						'custom-link' => esc_html__( 'Custom Link', 'halstein-core' ),
					),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'link',
					'title'      => esc_html__( 'Custom Link', 'halstein-core' ),
					'dependency' => array(
						'show' => array(
							'icon_action' => array(
								'values'        => 'custom-link',
								'default_value' => '',
							),
						),
					),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'link_target',
					'title'         => esc_html__( 'Custom Link Target', 'halstein-core' ),
					'options'       => halstein_core_get_select_type_options_pool( 'link_target' ),
					'default_value' => '_self',
					'dependency'    => array(
						'show' => array(
							'icon_action' => array(
								'values'        => 'custom-link',
								'default_value' => '',
							),
						),
					),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'color',
					'name'       => 'border_color',
					'title'      => esc_html__( 'Border Color', 'halstein-core' ),
					'group'      => esc_html__( 'Border Style', 'halstein-core' ),
				)
			);
		}

		public static function call_shortcode( $params ) {
			$html = qode_framework_call_shortcode( 'halstein_core_bordered_icon', $params );
			$html = str_replace( "\n", '', $html );

			return $html;
		}

		public function render( $options, $content = null ) {
			parent::render( $options );
			$atts = $this->get_atts();

			$atts['holder_classes'] = $this->get_holder_classes( $atts );
			$atts['border_styles']  = $this->get_border_styles( $atts );

			return halstein_core_get_template_part( 'shortcodes/bordered-icon', 'templates/bordered-icon', '', $atts );
		}

		private function get_holder_classes( $atts ) {
			$holder_classes = $this->init_holder_classes();

			$holder_classes[] = 'qodef-bordered-icon';

			return implode( ' ', $holder_classes );
		}

		private function get_border_styles( $atts ) {
			$styles = array();

			if ( ! empty( $atts['border_color'] ) ) {
				$styles[] = 'color: ' . $atts['border_color'];
			}

			return $styles;
		}
	}
}
