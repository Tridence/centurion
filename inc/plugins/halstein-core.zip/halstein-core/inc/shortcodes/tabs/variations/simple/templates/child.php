<div class="qodef-tabs-content" id="qodef-tab-<?php echo sanitize_title( $tab_title ); ?>">
	<?php echo do_shortcode( $content ); ?>
</div>
