<?php

if ( ! function_exists( 'halstein_core_add_icon_with_text_variation_top' ) ) {
	/**
	 * Function that add variation layout for this module
	 *
	 * @param array $variations
	 *
	 * @return array
	 */
	function halstein_core_add_icon_with_text_variation_top( $variations ) {
		$variations['top'] = esc_html__( 'Top', 'halstein-core' );

		return $variations;
	}

	add_filter( 'halstein_core_filter_icon_with_text_layouts', 'halstein_core_add_icon_with_text_variation_top' );
}
