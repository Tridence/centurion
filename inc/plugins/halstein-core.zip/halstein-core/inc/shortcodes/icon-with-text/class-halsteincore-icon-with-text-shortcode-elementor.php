<?php

class HalsteinCore_Icon_With_Text_Shortcode_Elementor extends HalsteinCore_Elementor_Widget_Base {

	public function __construct( array $data = [], $args = null ) {
		$this->set_shortcode_slug( 'halstein_core_icon_with_text' );

		parent::__construct( $data, $args );
	}
}

halstein_core_get_elementor_widgets_manager()->register( new HalsteinCore_Icon_With_Text_Shortcode_Elementor() );
