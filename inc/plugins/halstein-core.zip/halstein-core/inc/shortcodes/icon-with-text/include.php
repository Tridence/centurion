<?php

include_once HALSTEIN_CORE_SHORTCODES_PATH . '/icon-with-text/class-halsteincore-icon-with-text-shortcode.php';

foreach ( glob( HALSTEIN_CORE_SHORTCODES_PATH . '/icon-with-text/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
