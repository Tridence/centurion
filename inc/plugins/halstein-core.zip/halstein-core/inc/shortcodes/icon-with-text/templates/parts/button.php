<?php if ( class_exists( 'HalsteinCore_Button_Shortcode' ) && 'yes' === $enable_button ) { ?>
	<div class="qodef-m-button">
		<?php echo HalsteinCore_Button_Shortcode::call_shortcode( $button_params ); ?>
	</div>
<?php } ?>
