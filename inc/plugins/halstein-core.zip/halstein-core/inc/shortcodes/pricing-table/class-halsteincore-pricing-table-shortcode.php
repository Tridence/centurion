<?php

if ( ! function_exists( 'halstein_core_add_pricing_table_shortcode' ) ) {
	/**
	 * Function that add shortcode into shortcodes list for registration
	 *
	 * @param array $shortcodes
	 *
	 * @return array
	 */
	function halstein_core_add_pricing_table_shortcode( $shortcodes ) {
		$shortcodes[] = 'HalsteinCore_Pricing_Table_Shortcode';

		return $shortcodes;
	}

	add_filter( 'halstein_core_filter_register_shortcodes', 'halstein_core_add_pricing_table_shortcode' );
}

if ( class_exists( 'HalsteinCore_Shortcode' ) ) {
	class HalsteinCore_Pricing_Table_Shortcode extends HalsteinCore_Shortcode {

		public function __construct() {
			$this->set_layouts( apply_filters( 'halstein_core_filter_pricing_table_layouts', array() ) );
			$this->set_extra_options( apply_filters( 'halstein_core_filter_pricing_table_extra_options', array() ) );

			parent::__construct();
		}

		public function map_shortcode() {
			$this->set_shortcode_path( HALSTEIN_CORE_SHORTCODES_URL_PATH . '/pricing-table' );
			$this->set_base( 'halstein_core_pricing_table' );
			$this->set_name( esc_html__( 'Pricing Table', 'halstein-core' ) );
			$this->set_description( esc_html__( 'Shortcode that adds pricing table element', 'halstein-core' ) );
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'custom_class',
					'title'      => esc_html__( 'Custom Class', 'halstein-core' ),
				)
			);

			$options_map = halstein_core_get_variations_options_map( $this->get_layouts() );

			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'layout',
					'title'         => esc_html__( 'Layout', 'halstein-core' ),
					'options'       => $this->get_layouts(),
					'default_value' => $options_map['default_value'],
					'visibility'    => array( 'map_for_page_builder' => $options_map['visibility'] ),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'featured_table',
					'title'         => esc_html__( 'Featured Table', 'halstein-core' ),
					'options'       => halstein_core_get_select_type_options_pool( 'no_yes' ),
					'default_value' => 'no',
				)
			);
			$this->set_option(
				array(
					'field_type' => 'color',
					'name'       => 'table_background_color',
					'title'      => esc_html__( 'Background Color', 'halstein-core' ),
					'group'      => esc_html__( 'Content Style', 'halstein-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'text',
					'name'          => 'title',
					'title'         => esc_html__( 'Title', 'halstein-core' ),
					'default_value' => esc_html__( 'Title Text', 'halstein-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'title_tag',
					'title'         => esc_html__( 'Title Tag', 'halstein-core' ),
					'options'       => halstein_core_get_select_type_options_pool( 'title_tag' ),
					'default_value' => 'h6',
					'group'         => esc_html__( 'Title Style', 'halstein-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'color',
					'name'       => 'title_color',
					'title'      => esc_html__( 'Title Color', 'halstein-core' ),
					'group'      => esc_html__( 'Title Style', 'halstein-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'title_margin_bottom',
					'title'      => esc_html__( 'Title Margin Bottom', 'halstein-core' ),
					'group'      => esc_html__( 'Title Style', 'halstein-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'text',
					'name'          => 'price',
					'title'         => esc_html__( 'Price', 'halstein-core' ),
					'default_value' => esc_html__( '99', 'halstein-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'color',
					'name'       => 'price_color',
					'title'      => esc_html__( 'Price Color', 'halstein-core' ),
					'group'      => esc_html__( 'Price Style', 'halstein-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'text',
					'name'          => 'currency',
					'title'         => esc_html__( 'Currency', 'halstein-core' ),
					'default_value' => esc_html__( '$', 'halstein-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'currency_position',
					'title'         => esc_html__( 'Currency Position', 'halstein-core' ),
					'options'       => array(
						'left'  => esc_html__( 'Left', 'halstein-core' ),
						'right' => esc_html__( 'Right', 'halstein-core' ),
					),
					'default_value' => 'left',
				)
			);
			$this->set_option(
				array(
					'field_type' => 'color',
					'name'       => 'currency_color',
					'title'      => esc_html__( 'Currency Color', 'halstein-core' ),
					'group'      => esc_html__( 'Currency Style', 'halstein-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'html',
					'name'          => 'content',
					'title'         => esc_html__( 'Content', 'halstein-core' ),
					'default_value' => esc_html__( 'Contrary to popular belief, Lorem Ipsum is not simply random text.', 'halstein-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'content_margin_top',
					'title'      => esc_html__( 'Content Margin Top', 'halstein-core' ),
					'group'      => esc_html__( 'Content Style', 'halstein-core' ),
				)
			);
			$this->import_shortcode_options(
				array(
					'shortcode_base'    => 'halstein_core_button',
					'exclude'           => array( 'custom_class' ),
					'additional_params' => array(
						'nested_group' => esc_html__( 'Button', 'halstein-core' ),
					),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'divider_height',
					'title'      => esc_html__( 'Divider Height (px or %)', 'halstein-core' ),
					'group'      => esc_html__( 'Divider Style', 'halstein-core' ),
					'dependency' => array(
						'show' => array(
							'featured_table' => array(
								'values'        => 'no',
								'default_value' => 'no',
							),
						),
					),
				)
			);
			$this->map_extra_options();
		}

		public function render( $options, $content = null ) {
			parent::render( $options );
			$atts = $this->get_atts();

			$atts['holder_classes']  = $this->get_holder_classes( $atts );
			$atts['holder_styles']   = $this->get_holder_styles( $atts );
			$atts['divider_styles']  = $this->get_divider_styles( $atts );
			$atts['title_styles']    = $this->get_title_styles( $atts );
			$atts['price_styles']    = $this->get_price_styles( $atts );
			$atts['currency_styles'] = $this->get_currency_styles( $atts );
			$atts['content_styles']  = $this->get_content_styles( $atts );
			$atts['button_params']   = $this->generate_button_params( $atts );
			$atts['content']         = $this->get_editor_content( $content, $options );

			return halstein_core_get_template_part( 'shortcodes/pricing-table', 'variations/' . $atts['layout'] . '/templates/' . $atts['layout'], '', $atts );
		}

		private function get_holder_classes( $atts ) {
			$holder_classes = $this->init_holder_classes();

			$holder_classes[] = 'qodef-pricing-table';
			$holder_classes[] = ! empty( $atts['layout'] ) ? 'qodef-layout--' . $atts['layout'] : '';
			$holder_classes[] = ! empty( $atts['featured_table'] ) && 'yes' === $atts['featured_table'] ? 'qodef-status--featured' : 'qodef-status--regular';

			return implode( ' ', $holder_classes );
		}

		private function get_holder_styles( $atts ) {
			$styles = array();

			if ( ! empty( $atts['table_background_color'] ) ) {
				$styles[] = 'background-color: ' . $atts['table_background_color'];
			}

			return $styles;
		}

		private function get_divider_styles( $atts ) {
			$styles          = array();
			$rand_percentage = rand( 40, 80 );

			if ( ! empty( $atts['divider_height'] ) ) {
				if ( qode_framework_string_ends_with_space_units( $atts['divider_height'] ) ) {
					$styles[] = 'height: ' . $atts['divider_height'];
				} else {
					$styles[] = 'height: ' . intval( $atts['divider_height'] ) . 'px';
				}
			} else {
				$styles[] = 'height: ' . $rand_percentage . '%';
			}

			return $styles;
		}

		private function get_title_styles( $atts ) {
			$styles = array();

			if ( '' !== $atts['title_margin_bottom'] ) {
				if ( qode_framework_string_ends_with_space_units( $atts['title_margin_bottom'] ) ) {
					$styles[] = 'margin-bottom: ' . $atts['title_margin_bottom'];
				} else {
					$styles[] = 'margin-bottom: ' . intval( $atts['title_margin_bottom'] ) . 'px';
				}
			}

			if ( ! empty( $atts['title_color'] ) ) {
				$styles[] = 'color: ' . $atts['title_color'];
			}

			return $styles;
		}

		private function get_price_styles( $atts ) {
			$styles = array();

			if ( ! empty( $atts['price_color'] ) ) {
				$styles[] = 'color: ' . $atts['price_color'];
			}

			return $styles;
		}

		private function get_currency_styles( $atts ) {
			$styles = array();

			if ( ! empty( $atts['currency_color'] ) ) {
				$styles[] = 'color: ' . $atts['currency_color'];
			}

			return $styles;
		}

		private function get_content_styles( $atts ) {
			$styles = array();

			if ( '' !== $atts['content_margin_top'] ) {
				if ( qode_framework_string_ends_with_space_units( $atts['content_margin_top'] ) ) {
					$styles[] = 'margin-top: ' . $atts['content_margin_top'];
				} else {
					$styles[] = 'margin-top: ' . intval( $atts['content_margin_top'] ) . 'px';
				}
			}

			return $styles;
		}

		private function generate_button_params( $atts ) {
			$params = $this->populate_imported_shortcode_atts(
				array(
					'shortcode_base' => 'halstein_core_button',
					'exclude'        => array( 'custom_class' ),
					'atts'           => $atts,
				)
			);

			return $params;
		}
	}
}
