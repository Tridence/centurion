<?php

include_once HALSTEIN_CORE_SHORTCODES_PATH . '/pricing-table/class-halsteincore-pricing-table-shortcode.php';

foreach ( glob( HALSTEIN_CORE_SHORTCODES_PATH . '/pricing-table/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
