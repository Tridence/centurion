<?php if ( ! empty( $button_params ) ) { ?>
	<div class="qodef-m-button clear">
		<?php echo HalsteinCore_Button_Shortcode::call_shortcode( $button_params ); ?>
	</div>
<?php } ?>
