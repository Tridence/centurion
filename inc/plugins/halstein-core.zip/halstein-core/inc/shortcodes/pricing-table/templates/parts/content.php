<?php if ( ! empty( $content ) ) { ?>
	<div class="qodef-m-content" <?php qode_framework_inline_style( $content_styles ); ?>><?php echo do_shortcode( $content ); ?></div>
<?php } ?>
