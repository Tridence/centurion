<?php

include_once HALSTEIN_CORE_SHORTCODES_PATH . '/separator/class-halsteincore-separator-shortcode.php';
