<?php

include_once HALSTEIN_CORE_SHORTCODES_PATH . '/separator/widget/class-halsteincore-separator-widget.php';
