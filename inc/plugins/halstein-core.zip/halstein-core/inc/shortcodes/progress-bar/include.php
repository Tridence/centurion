<?php

include_once HALSTEIN_CORE_SHORTCODES_PATH . '/progress-bar/class-halsteincore-progress-bar-shortcode.php';
