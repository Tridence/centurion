<?php

include_once HALSTEIN_CORE_SHORTCODES_PATH . '/video-button/class-halsteincore-video-button-shortcode.php';
