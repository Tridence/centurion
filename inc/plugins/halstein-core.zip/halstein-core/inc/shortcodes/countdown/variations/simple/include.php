<?php

include_once HALSTEIN_CORE_SHORTCODES_PATH . '/countdown/variations/simple/helper.php';
