<?php

if ( ! function_exists( 'halstein_core_add_video_button_with_text_shortcode' ) ) {
	/**
	 * Function that add shortcode into shortcodes list for registration
	 *
	 * @param array $shortcodes
	 *
	 * @return array
	 */
	function halstein_core_add_video_button_with_text_shortcode( $shortcodes ) {
		$shortcodes[] = 'HalsteinCore_Video_Button_With_Text_Shortcode';

		return $shortcodes;
	}

	add_filter( 'halstein_core_filter_register_shortcodes', 'halstein_core_add_video_button_with_text_shortcode' );
}

if ( class_exists( 'HalsteinCore_Shortcode' ) ) {
	class HalsteinCore_Video_Button_With_Text_Shortcode extends HalsteinCore_Shortcode {

		public function __construct() {
			$this->set_layouts( apply_filters( 'halstein_core_filter_video_button_with_text_layouts', array() ) );
			$this->set_extra_options( apply_filters( 'halstein_core_filter_video_button_with_text_extra_options', array() ) );

			parent::__construct();
		}

		public function map_shortcode() {
			$this->set_shortcode_path( HALSTEIN_CORE_SHORTCODES_URL_PATH . '/video-button-with-text' );
			$this->set_base( 'halstein_core_video_button_with_text' );
			$this->set_name( esc_html__( 'Video Button With Text', 'halstein-core' ) );
			$this->set_description( esc_html__( 'Shortcode that adds video button with text element', 'halstein-core' ) );
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'custom_class',
					'title'      => esc_html__( 'Custom Class', 'halstein-core' ),
				)
			);

			$options_map = halstein_core_get_variations_options_map( $this->get_layouts() );

			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'layout',
					'title'         => esc_html__( 'Layout', 'halstein-core' ),
					'options'       => $this->get_layouts(),
					'default_value' => $options_map['default_value'],
					'visibility'    => array( 'map_for_page_builder' => $options_map['visibility'] ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'image',
					'name'       => 'content_background_image',
					'title'      => esc_html__( 'Content Background Image', 'halstein-core' ),
					'group'      => esc_html__( 'Content', 'halstein-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'content_margin',
					'title'      => esc_html__( 'Content Margin', 'halstein-core' ),
					'group'      => esc_html__( 'Content Style', 'halstein-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'content_padding',
					'title'      => esc_html__( 'Content Padding', 'halstein-core' ),
					'group'      => esc_html__( 'Content Style', 'halstein-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'color',
					'name'       => 'content_background_color',
					'title'      => esc_html__( 'Content Background Color', 'halstein-core' ),
					'group'      => esc_html__( 'Content Style', 'halstein-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'textarea',
					'name'          => 'text_field',
					'title'         => esc_html__( 'Text', 'halstein-core' ),
					'group'         => esc_html__( 'Content', 'halstein-core' ),
					'default_value' => esc_html__( 'Contrary to popular belief, Lorem Ipsum is not simply random text.', 'halstein-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type'  => 'text',
					'name'        => 'line_break_positions',
					'title'       => esc_html__( 'Positions of Line Break', 'halstein-core' ),
					'description' => esc_html__( 'Enter the positions of the words after which you would like to create a line break. Separate the positions with commas (e.g. if you would like the first, third, and fourth word to have a line break, you would enter "1,3,4")', 'halstein-core' ),
					'group'       => esc_html__( 'Text Style', 'halstein-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'disable_text_break_words',
					'title'         => esc_html__( 'Disable Text Line Break', 'halstein-core' ),
					'description'   => esc_html__( 'Enabling this option will disable text line breaks for screen size 1024 and lower', 'halstein-core' ),
					'options'       => halstein_core_get_select_type_options_pool( 'no_yes', false ),
					'default_value' => 'no',
					'group'         => esc_html__( 'Text Style', 'halstein-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'text_tag',
					'title'         => esc_html__( 'Text Tag', 'halstein-core' ),
					'options'       => halstein_core_get_select_type_options_pool( 'title_tag' ),
					'default_value' => 'h4',
					'group'         => esc_html__( 'Text Style', 'halstein-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'color',
					'name'       => 'text_color',
					'title'      => esc_html__( 'Text Color', 'halstein-core' ),
					'group'      => esc_html__( 'Text Style', 'halstein-core' ),
				)
			);
			$this->import_shortcode_options(
				array(
					'shortcode_base'    => 'halstein_core_video_button',
					'exclude'           => array( 'custom_class' ),
					'additional_params' => array(
						'nested_group' => esc_html__( 'Video Button', 'halstein-core' ),
					),
				)
			);

			$this->map_extra_options();
		}

		public function render( $options, $content = null ) {
			parent::render( $options );
			$atts = $this->get_atts();

			$atts['holder_classes']      = $this->get_holder_classes( $atts );
			$atts['content_styles']      = $this->get_content_styles( $atts );
			$atts['text_field']          = $this->get_modified_text( $atts );
			$atts['text_styles']         = $this->get_text_styles( $atts );
			$atts['video_button_params'] = $this->generate_video_button_params( $atts );

			return halstein_core_get_template_part( 'shortcodes/video-button-with-text', 'variations/' . $atts['layout'] . '/templates/' . $atts['layout'], '', $atts );
		}

		private function get_holder_classes( $atts ) {
			$holder_classes = $this->init_holder_classes();

			$holder_classes[] = 'qodef-video-button-with-text';
			$holder_classes[] = ! empty( $atts['layout'] ) ? 'qodef-layout--' . $atts['layout'] : '';
			$holder_classes[] = 'yes' === $atts['disable_text_break_words'] ? 'qodef-text-break--disabled' : '';

			return implode( ' ', $holder_classes );
		}

		private function get_content_styles( $atts ) {
			$styles = array();

			if ( ! empty( $atts['content_margin'] ) ) {
				$styles[] = 'margin: ' . $atts['content_margin'];
			}

			if ( ! empty( $atts['content_padding'] ) ) {
				$styles[] = 'padding: ' . $atts['content_padding'];
			}

			if ( ! empty( $atts['content_background_color'] ) ) {
				$styles[] = 'background-color: ' . $atts['content_background_color'];
			}

			return $styles;
		}

		private function get_text_styles( $atts ) {
			$styles = array();

			if ( ! empty( $atts['text_color'] ) ) {
				$styles[] = 'color: ' . $atts['text_color'];
			}

			return $styles;
		}

		private function get_modified_text( $atts ) {
			$text = $atts['text_field'];

			if ( ! empty( $text ) && ! empty( $atts['line_break_positions'] ) ) {
				$split_text           = explode( ' ', $text );
				$line_break_positions = explode( ',', str_replace( ' ', '', $atts['line_break_positions'] ) );

				foreach ( $line_break_positions as $position ) {
					$position = intval( $position );
					if ( isset( $split_text[ $position - 1 ] ) && ! empty( $split_text[ $position - 1 ] ) ) {
						$split_text[ $position - 1 ] = $split_text[ $position - 1 ] . '<br />';
					}
				}

				$text = implode( ' ', $split_text );
			}

			return $text;
		}

		private function generate_video_button_params( $atts ) {
			$params = $this->populate_imported_shortcode_atts(
				array(
					'shortcode_base' => 'halstein_core_video_button',
					'exclude'        => array( 'custom_class' ),
					'atts'           => $atts,
				)
			);

			return $params;
		}
	}
}
