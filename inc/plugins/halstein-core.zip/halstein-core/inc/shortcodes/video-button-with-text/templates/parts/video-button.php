<?php if ( class_exists( 'HalsteinCore_Video_Button_Shortcode' ) ) { ?>
	<div class="qodef-m-video-button">
		<?php echo HalsteinCore_Video_Button_Shortcode::call_shortcode( $video_button_params ); ?>
	</div>
<?php } ?>
