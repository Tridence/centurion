<div class="qodef-m-content-image">
	<?php echo wp_get_attachment_image( $content_background_image, 'full' ); ?>
</div>
