<?php

include_once HALSTEIN_CORE_SHORTCODES_PATH . '/video-button-with-text/class-halsteincore-video-button-with-text-shortcode.php';

foreach ( glob( HALSTEIN_CORE_INC_PATH . '/shortcodes/video-button-with-text/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
