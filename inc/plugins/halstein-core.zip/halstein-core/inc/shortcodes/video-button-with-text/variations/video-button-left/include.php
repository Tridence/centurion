<?php

include_once HALSTEIN_CORE_SHORTCODES_PATH . '/video-button-with-text/variations/video-button-left/helper.php';
