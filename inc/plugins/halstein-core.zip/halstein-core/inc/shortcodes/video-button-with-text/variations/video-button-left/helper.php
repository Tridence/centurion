<?php

if ( ! function_exists( 'halstein_core_add_video_button_with_text_variation_video_button_left' ) ) {
	/**
	 * Function that add variation layout for this module
	 *
	 * @param array $variations
	 *
	 * @return array
	 */
	function halstein_core_add_video_button_with_text_variation_video_button_left( $variations ) {
		$variations['video-button-left'] = esc_html__( 'Video Button Left', 'halstein-core' );

		return $variations;
	}

	add_filter( 'halstein_core_filter_video_button_with_text_layouts', 'halstein_core_add_video_button_with_text_variation_video_button_left' );
}
