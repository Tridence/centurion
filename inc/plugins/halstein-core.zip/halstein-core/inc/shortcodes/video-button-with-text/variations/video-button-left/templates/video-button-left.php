<div <?php qode_framework_class_attribute( $holder_classes ); ?>>
	<?php halstein_core_template_part( 'shortcodes/video-button-with-text', 'templates/parts/video-button', '', $params ); ?>
	<div class="qodef-m-content">
		<?php halstein_core_template_part( 'shortcodes/video-button-with-text', 'templates/parts/image', '', $params ); ?>
		<div class="qodef-m-content-inner" <?php qode_framework_inline_style( $content_styles ); ?>>
			<?php halstein_core_template_part( 'shortcodes/video-button-with-text', 'templates/parts/text', '', $params ); ?>
		</div>
	</div>
</div>
