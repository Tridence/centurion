<?php

include_once HALSTEIN_CORE_INC_PATH . '/social-share/shortcodes/social-share/widget/class-halsteincore-social-share-widget.php';
