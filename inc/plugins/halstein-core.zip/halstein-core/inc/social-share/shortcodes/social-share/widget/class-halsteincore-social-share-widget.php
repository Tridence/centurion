<?php

if ( ! function_exists( 'halstein_core_add_social_share_widget' ) ) {
	/**
	 * Function that add widget into widgets list for registration
	 *
	 * @param array $widgets
	 *
	 * @return array
	 */
	function halstein_core_add_social_share_widget( $widgets ) {
		$widgets[] = 'HalsteinCore_Social_Share_Widget';

		return $widgets;
	}

	add_filter( 'halstein_core_filter_register_widgets', 'halstein_core_add_social_share_widget' );
}

if ( class_exists( 'QodeFrameworkWidget' ) ) {
	class HalsteinCore_Social_Share_Widget extends QodeFrameworkWidget {

		public function map_widget() {
			$widget_mapped = $this->import_shortcode_options(
				array(
					'shortcode_base' => 'halstein_core_social_share',
				)
			);

			if ( $widget_mapped ) {
				$this->set_base( 'halstein_core_social_share' );
				$this->set_name( esc_html__( 'Halstein Social Share', 'halstein-core' ) );
				$this->set_description( esc_html__( 'Add a social share element into widget areas', 'halstein-core' ) );
			}
		}

		public function render( $atts ) {
			echo HalsteinCore_Social_Share_Shortcode::call_shortcode( $atts ); // XSS OK
		}
	}
}
