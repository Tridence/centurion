<?php

include_once HALSTEIN_CORE_INC_PATH . '/social-share/shortcodes/social-share/variations/text/helper.php';
