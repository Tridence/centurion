<?php

include_once HALSTEIN_CORE_INC_PATH . '/title/layouts/standard-with-breadcrumbs/helper.php';
include_once HALSTEIN_CORE_INC_PATH . '/title/layouts/standard-with-breadcrumbs/class-halsteincore-standard-with-breadcrumbs-title.php';
