<?php
// Load title image template
halstein_core_get_page_title_image();
?>
<div class="qodef-m-content <?php echo esc_attr( halstein_core_get_page_title_content_classes() ); ?>">
	<?php
	// Load breadcrumbs template
	halstein_core_breadcrumbs();
	?>
</div>
