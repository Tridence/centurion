<?php

include_once HALSTEIN_CORE_INC_PATH . '/title/layouts/breadcrumbs/helper.php';
include_once HALSTEIN_CORE_INC_PATH . '/title/layouts/breadcrumbs/class-halsteincore-breadcrumbs-title.php';
