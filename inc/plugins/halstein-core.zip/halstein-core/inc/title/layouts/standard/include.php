<?php

include_once HALSTEIN_CORE_INC_PATH . '/title/layouts/standard/helper.php';
include_once HALSTEIN_CORE_INC_PATH . '/title/layouts/standard/class-halsteincore-standard-title.php';
include_once HALSTEIN_CORE_INC_PATH . '/title/layouts/standard/dashboard/meta-box/standard-title-meta-box.php';
