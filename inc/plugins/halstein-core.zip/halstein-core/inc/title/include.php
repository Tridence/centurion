<?php

include_once HALSTEIN_CORE_INC_PATH . '/title/helper.php';
include_once HALSTEIN_CORE_INC_PATH . '/title/class-halsteincore-title.php';
include_once HALSTEIN_CORE_INC_PATH . '/title/class-halsteincore-titles.php';
